# RWA Rule Workbench — 로컬 관리 도구

**1.0.0-review · 기존 v5 / v5.0.2 프로젝트용 추가 도구**

CSV를 텍스트 에디터로 직접 편집하는 대신 브라우저에서 관리합니다. 규칙의 원본은 여전히 `rules/*.csv`이며, `command_patterns.txt`는 기존 `build_command_patterns.py`로 생성합니다. 기존 엔진을 다시 만들거나 별도의 모델/분류기를 추가하지 않았습니다.

## 가장 빠른 실행

Python 3.10 이상이 필요합니다. 운영용 pip 설치, Node, Flask, Django, 외부 CDN은 필요하지 않습니다.

1. **전체 포함 ZIP**을 새 폴더에 풀거나, **추가파일 ZIP**을 기존 전체 v5 프로젝트의 루트에 풉니다.
2. `rule_manager.py`와 `build_command_patterns.py`가 함께 있는 폴더에서 실행합니다.

```bash
python rule_manager.py
```

macOS / Linux에서 명령이 `python3`이면:

```bash
python3 rule_manager.py
```

브라우저가 자동으로 열립니다. 자동 열기가 안 되면 주소창에서 다음 주소를 엽니다.

```text
http://127.0.0.1:8765/
```

Windows에서는 `start_rule_manager.bat` 더블클릭도 가능합니다. macOS의 `.command` 실행이 OS 정책에 의해 막히면 정책을 해제하지 말고 승인된 터미널에서 Python 명령으로 실행하세요. 종료는 터미널에서 Ctrl+C입니다.

포트가 이미 사용 중인 경우:

```bash
python rule_manager.py --port 8766
```

다른 전체 프로젝트 폴더를 지정할 수도 있습니다. 선택한 프로젝트의 Python 소스는 신뢰할 수 있는 사본이어야 합니다.

```bash
python rule_manager.py --project "/approved/path/to/rwa-project" --no-open
```

이 경우 관리용 HTML/JS는 `rule_manager.py` 옆의 `local_manager/`에서, 실제 규칙·컴파일러·엔진은 지정한 프로젝트에서 읽습니다. 웹 배포 전용 ZIP에는 CSV/컴파일러가 없으므로 사용할 수 없습니다.

## 화면 구성

### 1. 규칙 편집

왼쪽 메뉴에서 다음 8개 CSV를 선택합니다.

| 메뉴 | 원본 CSV |
|---|---|
| 질문 표현·동의어 | `rules/synonyms.csv` |
| 후속질문 | `rules/followups.csv` |
| 그룹·계열사 별칭 | `rules/aliases.csv` |
| 명령·가중치 | `rules/commands.csv` |
| 안전한 오타 복구 | `rules/fuzzy_config.csv` |
| 숫자 단위 | `rules/units.csv` |
| 기간 표현 | `rules/temporal.csv` |
| 상속 정책·제한 | `rules/settings.csv` |

검색, 페이지 이동, 추가, 편집, 복제, 삭제, 비활성화가 가능합니다. CSV 불러오기는 **현재 선택한 표의 초안 전체**를 교체합니다. 잘못된 헤더는 거절합니다. CSV 내보내기는 현재 브라우저 초안을 UTF-8 BOM CSV로 다운로드합니다.

각 작업은 먼저 **브라우저 메모리의 초안**에만 반영됩니다. 탭을 닫으면 미저장 초안이 사라집니다. 필요한 초안은 CSV 내보내기로 보관하세요. 자동 학습·자동 운영 배포는 없습니다.

### 2. 초안 검증·빌드

상단 **초안 검증·빌드**는 8개 CSV 초안을 임시 폴더에 기록한 뒤 기존 Python 컴파일러를 실행합니다. 실제 원본 CSV와 현재 `command_patterns.txt`는 바뀌지 않습니다.

컴파일러가 실패하면 파일명·행 번호·오류 이유를 보여주고 저장을 막습니다. 컴파일러는 일반적으로 첫 오류를 반환하므로 수정 후 다시 검증합니다. 검증 성공은 문법/스키마 검사 통과이지 금융 의미 또는 모든 질문의 정확성 승인과 같지 않습니다.

### 3. 질문 테스트

**현재 저장 버전**과 **검증된 초안** 중 선택할 수 있습니다. 테스트는 기존 `RwaQaEngine`, `semantic/` 모듈, 기존 CSV/JSON 변환 함수를 브라우저에서 그대로 실행합니다.

- **해석 확인**: 명령·그룹·계열사·기간·Top N·제외·threshold를 보여줍니다. 대화 상태를 갱신하지 않습니다.
- **샘플 계산·문맥 적용**: 로컬 자료로 실제 계산을 수행합니다. 성공한 경우에만 테스트 대화 상태를 갱신합니다.
- **여러 줄 연속 실행**: 한 줄에 한 질문씩, 새 테스트 문맥에서 최대 30개를 순차적으로 실행합니다. 실패 또는 자료 부족 시 중단합니다.
- **테스트 대화 초기화**: 테스트 문맥과 테스트 history를 비웁니다. 본 RWA 웹앱의 history는 건드리지 않습니다.

예:

```text
Why did Samsung's RWA increase in July?
How about Toyota?
And August?
```

프로젝트의 원래 샘플에는 Toyota 8월 자료가 없습니다. 따라서 8월을 인식하더라도 실제 계산은 자료 없음으로 중단하는 것이 정상입니다. 별칭을 추가했다고 실제 금융 데이터나 권한이 생기지는 않습니다.

기본 자료는 해당 프로젝트의 `tableau_sample.csv`, `rwa_sample_data.txt`, `rules_config.txt`입니다. 사용자 프로젝트에서 이 파일을 실데이터로 바꿨다면 더 이상 합성 자료가 아니므로 접근·백업·화면 캡처를 관리해야 합니다.

승인된 CSV 또는 rows 배열 JSON을 테스트 자료로 직접 선택할 수도 있습니다. 선택한 파일은 이 브라우저 탭에서만 읽고 Python 서버로 업로드하지 않습니다. 테스트 금액 단위는 **USDm**입니다. 다른 단위의 자료는 먼저 승인된 방식으로 정규화하세요. 현재 Tableau의 실제 필터/권한/SSO를 이 관리 도구가 재현하는 것은 아닙니다.

### 4. 디버그와 회귀 검사

상세 결과에서 matched phrases, fuzzy, 후보 점수, constraints, context patch, 원본 질문을 볼 수 있습니다. 매칭 점수는 정답 확률이 아닙니다.

12개 기본 검사는 개발용 smoke check입니다. 정확도/독립 holdout/MiniLM 우월성의 근거가 아닙니다. 사용자 검사 JSON 형식:

```json
[
  {
    "id": "CUSTOM_001",
    "query": "Take me through Samsung's RWA movement in July.",
    "context": {"selectedClientGroup": "SAMSUNG GROUP", "selectedMonth": "2026-07"},
    "expected": {"ok": true, "action": "GROUP_ROOT_CAUSE", "group": "SAMSUNG GROUP", "month": "2026-07"}
  }
]
```

허용된 expected 항목은 `ok`, `code`, `action`, `group`, `entity`, `month`, `topN`, `excludedDrivers`, `condition`입니다. 지정한 항목만 비교하므로 일부 필드 테스트를 전체 end-to-end 정확도로 해석하지 마세요. 후속 대화는 동일한 `sequence` 값을 사용하고, 앞선 턴에 `commit: true`를 넣어 실제 로컬 계산이 성공한 후 문맥을 이어갑니다.

질문·결과는 자동으로 디스크에 기록하지 않습니다. 결과 JSON 다운로드는 사용자의 명시적 작업이며 민감한 질문/그룹명이 포함될 수 있습니다.

### 5. CSV 저장·생성파일 갱신

검증이 끝나면 **CSV 저장·생성파일 갱신**이 활성화됩니다. 확인창에서 변경 파일을 확인하고 저장합니다.

```text
브라우저 초안
  → 기존 Python 컴파일러 검증
  → 임시 command_patterns.txt
  → 질문 테스트 (권장, 자동 승인 아님)
  → 명시적인 저장 확인
  → 기존 CSV/생성파일 백업
  → CSV 교체
  → command_patterns.txt 최종 교체
```

**생성파일만 직접 수정하지 않습니다.** 저장 후 버튼으로 최신 `command_patterns.txt`를 다운로드할 수 있습니다. 실제 사내 웹사이트에는 자동 업로드하지 않으므로 승인된 절차로 생성 파일을 교체하고 앱을 새로고침하세요. 웹 서버가 같은 로컬 프로젝트 파일을 읽는 개발 설정이면 그 생성 파일은 즉시 바뀝니다. 운영 디렉터리에서 직접 이 도구를 실행하지 말고 작업 사본을 사용하세요.

원래 단일 `standalone_demo.html`에는 규칙이 내장되어 있어 이 도구의 저장만으로 자동 갱신되지 않습니다.

## 실패·동시 수정·백업 보호

- 검증 실패 시 원본 파일을 덮어쓰지 않습니다.
- 검증 후 CSV나 생성 파일이 다른 에디터/탭에서 바뀌면 revision 충돌로 저장을 거절합니다.
- 엔진/컴파일러 소스가 실행 중 변경되면 관리자 서버 재시작을 요구합니다.
- 같은 프로젝트에 두 개의 관리자 서버를 띄우지 못하도록 OS 파일 잠금을 사용합니다.
- 저장 전 `.rule_manager/backups/<timestamp-id>/before/`에 이전 파일을 보관합니다.
- **개별 파일 교체는 atomic**이며, 여러 파일 전체가 하나의 OS 원자적 트랜잭션인 것은 아닙니다. 중단 복구 journal과 rollback을 별도로 구현했습니다. 생성 파일은 마지막에 교체합니다.
- 저장 도중 예외가 발생하면 알려진 transaction 상태에 한해 복원합니다. 프로세스 강제종료 등으로 journal이 남으면 다음 시작 시 복구를 확인합니다.
- 외부에서 다시 수정된 알 수 없는 파일은 자동 복원으로 덮어쓰지 않고 수동 복구를 요청합니다.
- 백업 복원도 현재 파일을 백업한 뒤 기존 컴파일러로 CSV를 재검증·재생성합니다.

다른 프로그램의 동시 파일 쓰기나 모든 파일시스템·정전 상황까지 보장하지 않습니다. CSV를 Excel 등에서 동시에 수정하지 마세요. 사용자별 OS 백업·승인·접근통제는 그대로 필요합니다. 백업은 자동 삭제하지 않으며 최신 50개가 화면에 표시됩니다. 검토 후 보존 정책에 따라 로컬 백업을 정리하세요.

## 보안 범위

**단일 사용자의 로컬 개발·규칙 관리용**입니다. 공용·사내 다중 사용자 관리 서버가 아닙니다.

- `127.0.0.1`에만 바인딩하며 외부 호스트 바인딩 옵션이 없습니다.
- 정확한 Host, 같은 Origin, CSRF 토큰, JSON Content-Type을 검사합니다. CORS를 열지 않습니다.
- 고정 allowlist 경로만 제공하며 Python 소스, 임의 파일, Tableau 설정/credentials, 백업 디렉터리를 정적 서버로 노출하지 않습니다.
- 실행 코드는 선택한 신뢰된 프로젝트의 기존 컴파일러로 고정되어 있습니다. HTTP에서 shell 명령이나 Python 경로를 받지 않습니다.
- 문장·CSV 셀은 `textContent` 등 안전한 텍스트 출력으로 표시합니다. CSV 수식형 입력도 제한합니다.
- 외부 CDN·모델 다운로드·telemetry·외부 AI API를 사용하지 않습니다. 테스트 화면은 Tableau 서버에 연결하지 않습니다.
- 질문·수치·토큰을 요청 로그로 남기지 않습니다. 백업에는 규칙과 별칭 정보가 들어가므로 민감한 자료로 취급하세요.
- 로컬 프로세스나 같은 OS 계정의 악성 프로그램을 막는 인증 시스템은 아닙니다. CSRF 토큰은 사내 승인 인증서가 아닙니다.

Python 공식 문서는 `http.server`를 production 서버로 권장하지 않습니다. 이 도구를 네트워크 공개 관리 서버로 배포하지 마세요. OWASP의 same-origin/CSRF 보호 원칙을 적용했지만 침투 테스트나 은행 보안 승인을 완료한 것은 아닙니다.

References:
- Python official: https://docs.python.org/3/library/http.server.html
- OWASP CSRF prevention: https://cheatsheetseries.owasp.org/cheatsheets/Cross-Site_Request_Forgery_Prevention_Cheat_Sheet.html

**No ML ≠ Non-AI approval.** 기존 규칙 엔진의 귀행 거버넌스 분류, 개발에 AI가 사용된 사실, 규칙 변경 승인은 별도 검토 사항입니다.

## 검증 범위

`local_manager_reports/`에 이번 추가 도구의 결과를 기록합니다. Python 표준 라이브러리 테스트는 실제 기존 컴파일러·임시 프로젝트 파일 저장·백업·충돌·복원과 실제 loopback HTTP 요청을 확인했습니다. 이 환경의 Chromium은 localhost 탐색을 `ERR_BLOCKED_BY_ADMINISTRATOR`로 차단하므로 해당 정책을 변경하지 않았습니다. 브라우저 화면/엔진 테스트는 **실제 동일 JS 모듈 + 미리 컴파일한 fixture + mock API를 쓰는 격리 DOM**으로 수행했습니다. 실제 브라우저 HTTP ESM/fetch/서버 CSP·은행 Tableau/SSO/SharePoint의 통합 검증과 같지 않습니다.

```bash
# 새 관리 도구 backend 회귀 검사. 테스트 프로젝트 임시 사본을 사용합니다.
python local_manager_tests/run_report.py

# 기존 RWA 전체 회귀 검사 (선택적 개발 Node 환경)
node tests/run_all.mjs
```

브라우저 개발 테스트에는 별도 Playwright/Chromium이 필요하지만 일반 사용에는 필요 없습니다. `browser_smoke.py`의 real HTTP 검사는 승인된 개발 환경에서 임시 프로젝트 복사본으로 실행하세요. 원본 규칙에 테스트용 행을 추가·저장·복원하므로 운영 작업 폴더에서 직접 실행하지 마세요.
