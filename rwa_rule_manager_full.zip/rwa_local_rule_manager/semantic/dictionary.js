import {norm,tokenize,uniq,overlaps} from './text.js';
/** Layer 2: exact literal trie lookup, longest phrase first. No frequency fitting or embeddings. */
export class PhraseIndex {
  constructor(entries) {
    this.root=new Map();
    for(const entry of entries){
      const words=tokenize(norm(entry.phrase)).map(t=>t.text);if(!words.length)continue;
      let node=this.root;
      for(const word of words){if(!node.has(word))node.set(word,new Map());node=node.get(word);}
      if(!node.has(''))node.set('',[]);node.get('').push(entry);
    }
  }
  match(text,blocked=[]) {
    const tokens=tokenize(text),out=[];
    for(let i=0;i<tokens.length;i++){
      if(blocked.some(s=>overlaps(s,tokens[i])))continue;
      let node=this.root,last=null;
      for(let j=i;j<tokens.length;j++){
        if(blocked.some(s=>overlaps(s,tokens[j]))||!node.has(tokens[j].text))break;
        node=node.get(tokens[j].text);
        if(node.has(''))last={start:tokens[i].start,end:tokens[j].end,text:text.slice(tokens[i].start,tokens[j].end),entries:node.get(''),last:j};
      }
      if(last){out.push(last);i=last.last;}
    }
    return out;
  }
}
export function identityCatalog(rows=[],catalog=null,options={}) {
  const identities=new Map();
  const add=(kind,id,name,parentId='',parentName='',aliases=[])=>{
    if(!id||!name)return;
    const key=kind+':'+(kind==='ENTITY'?parentId+'/':'')+id;
    if(!identities.has(key))identities.set(key,{key,kind,id,name,parentId,parentName,aliases:[]});
    const old=identities.get(key);old.aliases=uniq([...old.aliases,id,name,...aliases].filter(Boolean));
  };
  for(const g of catalog?.groups||[])add('GROUP',g.client_group_id,g.client_group_name,'','',options.registry?[]:(g.aliases||[]));
  for(const e of catalog?.entities||[]){const g=catalog.groups.find(g=>g.client_group_id===e.client_group_id);add('ENTITY',e.entity_id,e.entity,e.client_group_id,g?.client_group_name||'',options.registry?[]:(e.aliases||[]));}
  for(const row of rows){
    const gid=row.client_group_id||row.client_group;
    add('GROUP',gid,row.client_group,'','',options.registry?[]:(options.groupAliases?.[row.client_group]||[]));
    add('ENTITY',row.entity_id||row.entity,row.entity,gid,row.client_group,options.registry?[]:(options.entityAliases?.[row.entity]||[]));
  }
  // CSV aliases bind only to existing IDs; never manufacture an authorised target.
  for(const a of options.registry?.aliases||[]){
    if(!a.enabled)continue;
    const key=a.kind+':'+(a.kind==='ENTITY'?a.parent_id+'/':'')+a.canonical_id;
    const identity=identities.get(key);
    if(identity)identity.aliases=uniq([...identity.aliases,a.alias]);
  }
  return [...identities.values()];
}
export class Dictionary {
  constructor(registry,identities){
    this.registry=registry;this.identities=identities;
    this.nameIndex=new PhraseIndex(identities.flatMap(item=>item.aliases.map(phrase=>({phrase,item}))));
    this.conceptIndex=new PhraseIndex(registry.synonyms.filter(s=>s.enabled));
  }
  resolve(text){
    const hits=this.nameIndex.match(text),names=[],collisions=[];
    for(const h of hits){
      const targets=[...new Map(h.entries.map(e=>[e.item.key,e.item])).values()];
      if(targets.length>1)collisions.push({text:h.text,targets:targets.map(x=>({kind:x.kind,id:x.id,name:x.name,parentId:x.parentId}))});
      else names.push({...h,item:targets[0],entries:undefined});
    }
    const matches=this.conceptIndex.match(text,hits).map(h=>({...h,concept:h.entries[0].concept,weight:h.entries[0].weight,source:h.entries[0].source,entries:undefined}));
    const concepts=Object.create(null);
    for(const m of matches)concepts[m.concept]=Math.max(concepts[m.concept]||0,m.weight);
    return {names,matches,concepts,collisions};
  }
}
/** Compatibility helpers retained for callers; ambiguity is preserved rather than picking a target. */
export function findNames(q,items){
  const idx=new PhraseIndex(items.flatMap(item=>uniq(item.aliases||[]).map(phrase=>({phrase,item}))));
  return idx.match(norm(q)).flatMap(h=>[...new Map(h.entries.map(e=>[e.item.key,e.item])).values()].map(item=>({...item,start:h.start,end:h.end,text:h.text})));
}
export function catalogMentions(q,groups){return findNames(q,groups.map(g=>({key:g.client_group_id,name:g.client_group_name,kind:'group',aliases:[g.client_group_id,g.client_group_name,...(g.aliases||[])]})));}
