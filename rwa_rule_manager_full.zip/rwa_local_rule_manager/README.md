# UI update: v5.0.2

The core engine remains v5. The v5.0.1 five-second title screen now includes CSS wave dots. See `PATCH_WAVE_DOTS.md` for the two-file update and current UI test scope. All sections below describe the retained core v5 implementation.

> **UI patch 5.0.1:** Added a five-second title-only splash with a 720ms upward exit. Core engine remains v5. See `PATCH_LOADING_SCREEN.md` for changed files, configuration and current UI test scope.

# RWA Reports — deterministic semantic rules v5

**5.0.0-review · 기존 v4에 통합한 production-like 검토 빌드**

v4의 UI, chat history, 실행 전 preview/confirm, Tableau v2 연결, 데이터 계약과 계산 함수를 유지하고 문장 해석을 보강했습니다. 운영 브라우저에는 ML/LLM/MiniLM/learned embedding/ONNX/Transformers.js/모델용 WASM/외부 AI API가 없습니다. 모델 없는 개발용 Python 컴파일러는 CSV 검증과 생성만 수행합니다. 원본 MiniLM은 선택적 A/B 개발 환경에만 별도 보존합니다.

**Non-ML은 비AI 분류나 사내 승인 완료를 뜻하지 않습니다.** 이번 변경의 실제 기능·코드·CSV 관리 절차를 귀행에서 검토하십시오. AI의 도움으로 개발된 코드이며 개발 도구 사용 정책도 별도입니다.

## 빠른 확인

`standalone_demo.html`을 JavaScript를 실행하는 브라우저에서 엽니다. 합성 데이터만 포함합니다. 파일 미리보기 앱은 실행하지 않을 수 있습니다. 정상 데모는 내부 점수/fuzzy debug를 숨깁니다.

```text
Why did Samsung's RWA increase in July?
How about Toyota?
And August?
```

각 요청의 조건을 확인하고 **Run report**를 누릅니다. 실제 샘플의 Samsung/Toyota 7월은 감소이므로 증가를 만들어내지 않습니다. 원본 샘플에는 Toyota 8월이 없어 마지막 요청은 정확하게 해석한 뒤 데이터 없음으로 중단합니다. 자동 테스트만 명시적으로 추가한 합성 8월 자료를 사용합니다.

```text
comapre Samsung and Toyota in July
Why did Samsng RWA increse in July?
Show top ten groups with RWA above 25 million in June
Show groups by percentage increase above 10% in June
Show top 10 excluding groups below 25m in June
Explain Samsung in last quarter
```

## 실제 웹 앱

승인된 정적 호스트에 `demo.html`과 모든 runtime 파일을 함께 올립니다. 로컬 확인은 `node serve.mjs` 후 `http://127.0.0.1:8000/demo.html`입니다. 브라우저 운영에는 Node/Python 서버가 필수가 아닙니다. ES module/fetch 앱인 `demo.html`의 file:// 직접 실행은 지원하지 않습니다.

기본 설정은 `sample`, `requireConfirmation: true`, `liveReviewAcknowledged: false`입니다. 검토 없이 live 연결을 활성화하지 마십시오. 내부 URL, worksheet, access controls, 카탈로그는 기존 승인값을 유지합니다. `MIGRATION.md`를 참조하십시오.

## CSV → 컴파일 → 배포

```bash
# rules/*.csv를 UTF-8 CSV로 편집
python build_command_patterns.py
python build_command_patterns.py --check
node tests/run_all.mjs
```

성공했을 때만 생성된 `command_patterns.txt`가 원자적으로 교체됩니다. 실패하면 이전 파일을 유지합니다. Python 3.10+ 표준 라이브러리만 필요하며 pip/학습이 없습니다. CSV 저장 시 ID의 선행 0이나 날짜 문자열을 spreadsheet 앱이 바꾸지 않도록 텍스트 열로 유지하십시오.

| 원본 CSV | 용도 |
|---|---|
| `commands.csv` | 명령, 명시적 특징/가중치, grammar ID, 필수/선택/금지 슬롯 |
| `synonyms.csv` | 단어·긴 구문 → canonical concept |
| `aliases.csv` | 승인된 그룹/계열사 ID·parent ID·이름·별칭 |
| `followups.csv` | 후속 표현 → 허용된 상태 patch |
| `settings.csv` | Top-K, 입력/기간 제한, 상속 정책 |
| `fuzzy_config.csv` | 범주별 최소 길이·유사도·편집 한도·margin·횟수 |
| `units.csv` | 단위와 고정 배수 |
| `temporal.csv` | 월 이름과 명시적 상대 기간 |

HTML editor는 원본 관리용이 아닙니다. `command_patterns.txt`를 직접 편집하지 마십시오. 새 표현은 CSV로 추가할 수 있지만 새로운 계산/슬롯/grammar 의미는 코드 검토와 테스트가 필요합니다. 상세 형식은 `COMMANDS.md`에 있습니다.

## Safe fuzzy: 오타 복구에만 사용

정확한 이름/단어/긴 구문을 먼저 처리합니다. 남은 알파벳 token만 등록된 후보에 대해 bounded edit distance로 비교합니다. 인접 문자 전치 비용은 1입니다. 후보끼리 근접하면 거절하며 숫자·금액·단위·날짜·짧은 약어는 복구하지 않습니다.

기본값은 semantic word 최소 5자/0.80/1 edit/최대 2개, identity 최소 5자/0.83/1 edit/최대 1개입니다. identity 후보는 CSV의 실제 알려진 ID에 연결된 alias만 사용합니다. 0.83은 정답 확률이나 인증 기준이 아닙니다. 잘못된 유사 이름을 모든 경우 방지한다고 보장하지 않습니다.

**현재 fuzzy는 단일 단어 alias만 지원**합니다. 여러 단어의 이름은 정확 매칭을 지원하며, multi-word fuzzy는 지원하지 않습니다. fuzzy가 성공해도 추가 근거·점수·grammar·슬롯 제약을 통과하지 않으면 실행하지 않습니다. 자동 사전 추가/학습/파일 변경은 없습니다.

## 숫자·단위·기간

`25m`, `25 mn`, `25 million`, `25,000,000`은 기본 절대값 **25000000**으로 표현합니다. 기존 USDm 실행 함수에는 **25**를 전달합니다. `1.5bn`은 1500000000, `10%`는 ratio 0.1, `25bps`는 ratio 0.0025입니다. 기존 성장률 필터에는 percentage points로 변환합니다. 원문·canonical 값·실행 단위를 모두 보존합니다.

`25m`를 RWA **balance**로 해석하는 명령은 `with RWA above 25m`처럼 명시합니다. 단순 `groups above 25m`은 기존 기본값인 **signed RWA change** 필터이며 preview에 표시됩니다. 숫자 bound가 있고 방향을 말하지 않았다면 포트폴리오 순감소 때문에 양수 증가 그룹을 제외하지 않습니다. 명시적인 decline/absolute-magnitude threshold, 여러 bound/OR, 통화 환산은 지원하지 않습니다. USDm 이외 데이터의 금액 threshold는 거절합니다. %/bps는 비율 기능이 있는 명령에서만 사용할 수 있으며 bps를 금액으로 바꾸지 않습니다.

`over 12m`는 ranking 금액 문맥이면 12 million, `trend over 12m`는 12개월입니다. 월/분기/YTD/윈도우는 분석 context 기준입니다. 정상 follow-up은 마지막 성공한 분석 월, 완전한 새 질문은 Tableau 선택 월, 없으면 로드된 최신 보고 월을 사용합니다. 시스템 오늘 날짜로 임의 해석하지 않습니다. `current quarter`는 **전체 분기**이며 QTD가 아닙니다. 데이터가 부족하면 중단합니다.

## 후속 질문과 실제 데이터

`How about Toyota?`는 대상만, `And August?`는 기간만 바꿉니다. `Only those above 25m`은 직전 표시된 ID 집합을 제한합니다. 최근 rank reference에는 ID/이름/순위만 보관합니다. RWA 값이나 원인 결론은 새 대상에 상속하지 않습니다. 확인 취소/실패/오래된 preview는 정상 실행 state를 갱신하지 않습니다.

`Did RWA increase?`는 실제 증감 여부를 확인합니다. `How much did RWA increase?`는 금액 중심 보고, `Why did RWA increase?`는 기여분 보고입니다. `Why didn't RWA increase?`는 모호한 부정 원인 추론으로 거절합니다. `Didn't RWA increase?`는 '증가하지 않았다'는 명제를 명시한 뒤 확인합니다.

## Debug와 테스트

```bash
node tools/explain.mjs "comapre Samsung and Toyota in July"
node tools/evaluate.mjs tests/robustness.csv reports/robustness.json
node tools/failure_analysis.mjs reports/robustness.json reports/failure_analysis.json
python tests/browser_test.py --mode dom
python tests/browser_test.py --mode http
```

정상 UI는 debug를 숨깁니다. 승인된 개발 설정에서만 `tableau_config.txt`에 `"debug": true`를 추가하면 자세한 추적을 볼 수 있습니다. 데이터가 포함되므로 접근을 통제하십시오. CLI explain은 계산/외부 통신 없이 parse 결과를 출력합니다. 단일 HTML은 외부 설정 변경으로 갱신되지 않아 다시 빌드해야 합니다.

기존 626개 + 새 225개 질문은 **개발자 작성 회귀 세트**입니다. 새 지원 요청 159개는 25개의 기대 파라미터를 모두 명시해 command exact-match를 검증합니다. 그중 147개는 합성 자료로 실제 답변하고 12개는 해당 기간 자료가 없어 중단했습니다. 이것을 모두 금융 답변 성공이라고 집계하지 않습니다. 수용 기준/수치는 `reports/release_summary.json`, `BENCHMARK.md`를 보십시오.

`tests/holdout_template.csv`는 빈 양식입니다. 독립 holdout이 제공되지 않았으므로 **blind 성능 결과는 없습니다**. `tools/holdout_guard.py`는 사전 code freeze·corpus hash·기존 질문 중복을 확인하나 독립성을 증명하지 않습니다.

## 배포 한계

실제 은행 Tableau/SSO/SharePoint/RLS/CSP/권한/침투 테스트를 완료하지 않았습니다. HTTP 브라우저 탐색은 환경 관리 정책에 의해 차단되어 정책을 우회하지 않고 메모리 HTML만 시험했습니다. 24개 브라우저 체크는 실제 은행 연동 인증이 아닙니다.

이 시스템은 영어의 제한된 historical RWA reporting을 지원합니다. 새로운 경제적 원인/예측/최적화/여신 결정/범용 영어 추론은 지원하지 않습니다. 제공된 additive driver의 정합성 및 데이터 권한은 upstream에서 보장해야 합니다. `FX 제외`는 기록된 기여분 차감이며 환율 불변 재계산이 아닙니다. `ACCEPTANCE.md`, `CISO_SECURITY.md`, `DEPLOYMENT_REVIEW.md`를 검토하십시오.
