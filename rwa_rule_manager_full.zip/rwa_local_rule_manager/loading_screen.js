/* Presentation only. No query, data, network or conversation-state changes.
 * Minimum visibility is configured on #rwa-loading-screen in demo.html.
 * bootstrap.js signals completion (including errors) without being delayed.
 */
(() => {
  'use strict';
  const root = document.documentElement;
  const ACTIVE = 'rwa-splash-active';
  const EXITING = 'rwa-splash-exiting';
  const SETTLED = 'rwa:initialization-settled';
  let mounted = false, settled = root.dataset.rwaInitialization === 'settled';
  let screen, title, startedAt = 0, minimumMs = 5000, exiting = false, finished = false;
  let minimumTimer, watchdogTimer, exitTimer, titleObserver;
  const savedAttributes = [];

  // Installed in <head>, before the body can paint: no flash of the main screen.
  // If this optional script is blocked, its class is never applied and the
  // original application remains visible rather than being permanently covered.
  root.classList.add(ACTIVE);

  function emit(name, reason) {
    document.dispatchEvent(new CustomEvent(name, {
      detail: {reason, elapsedMs: mounted ? performance.now() - startedAt : 0}
    }));
  }

  function syncTitle() {
    const heading = document.querySelector('body > header h1');
    if (!heading || !title) return;
    const copy = heading.cloneNode(true);
    copy.querySelectorAll('.badge, [aria-hidden="true"]').forEach(node => node.remove());
    const text = copy.textContent.trim();
    if (text) title.textContent = text;
  }

  function finish(reason) {
    if (finished) return;
    finished = true;
    clearTimeout(minimumTimer); clearTimeout(watchdogTimer); clearTimeout(exitTimer);
    if (titleObserver) titleObserver.disconnect();
    document.removeEventListener(SETTLED, onSettled);
    window.removeEventListener('error', onScriptError, true);
    if (screen) {
      screen.removeEventListener('transitionend', onTransitionEnd);
      screen.hidden = true;
    }
    for (const entry of savedAttributes) {
      for (const [attribute, value] of Object.entries(entry.attributes)) {
        if (value === null) entry.element.removeAttribute(attribute);
        else entry.element.setAttribute(attribute, value);
      }
    }
    root.classList.remove(ACTIVE, EXITING);
    root.dataset.rwaLoadingState = 'done';
    emit('rwa:splash-hidden', reason);
    // No autofocus: do not open the mobile keyboard or steal the user's focus.
  }

  function onTransitionEnd(event) {
    if (event.target === screen && ['transform', 'opacity'].includes(event.propertyName)) {
      finish(root.dataset.rwaLoadingExitReason);
    }
  }

  function transitionMs(element) {
    const style = getComputedStyle(element);
    const parse = value => value.trim().endsWith('ms') ? parseFloat(value) : parseFloat(value) * 1000;
    const times = style.transitionDuration.split(',').map(parse);
    const delays = style.transitionDelay.split(',').map(parse);
    return Math.max(0, ...times.map((time, i) => time + delays[i % delays.length]));
  }

  function exit(reason) {
    if (!mounted || exiting || finished) return;
    const remaining = minimumMs - (performance.now() - startedAt);
    if (remaining > 0) {
      clearTimeout(minimumTimer);
      minimumTimer = setTimeout(() => exit(reason), remaining + 1);
      return;
    }
    exiting = true;
    clearTimeout(watchdogTimer);
    root.dataset.rwaLoadingState = 'exiting';
    root.dataset.rwaLoadingExitReason = reason;
    screen.addEventListener('transitionend', onTransitionEnd);
    root.classList.add(EXITING);
    emit('rwa:splash-exiting', reason);
    // Also releases the cover when a browser skips/cancels CSS transitions.
    exitTimer = setTimeout(() => finish(reason), transitionMs(screen) + 120);
  }

  function onSettled() {
    settled = true;
    if (mounted) exit('settled');
  }

  function onScriptError(event) {
    const script = event.target;
    if (!script || script.tagName !== 'SCRIPT') return;
    const url = script.getAttribute('src') || '';
    if (!/(^|\/)bootstrap\.js(?:[?#]|$)/.test(url)) return;
    const status = document.getElementById('status');
    if (status) {
      status.classList.add('error');
      status.textContent = 'Initialization failed: the application script could not be loaded. Check the deployment and reload this page.';
    }
    const progress = document.getElementById('progress');
    if (progress) progress.hidden = true;
    settled = true;
    if (mounted) exit('load-error');
  }

  function mount() {
    if (mounted || finished) return;
    screen = document.getElementById('rwa-loading-screen');
    title = document.getElementById('rwa-loading-title');
    if (!screen) { finish('no-screen'); return; }
    mounted = true;
    startedAt = performance.now();
    const configured = Number(screen.dataset.minimumMs);
    minimumMs = Number.isFinite(configured) && configured >= 0 && configured <= 60000 ? configured : 5000;
    root.dataset.rwaLoadingState = 'waiting';
    syncTitle();
    const heading = document.querySelector('body > header h1');
    if (heading) {
      titleObserver = new MutationObserver(syncTitle);
      titleObserver.observe(heading, {childList: true, subtree: true, characterData: true});
    }
    // Keep the Tableau host measurable. Do NOT use display:none or hidden on
    // the application: embedding/initialization still runs underneath the cover.
    for (const element of document.querySelectorAll('body > header, body > main, body > footer')) {
      savedAttributes.push({element, attributes: {
        inert: element.getAttribute('inert'), 'aria-hidden': element.getAttribute('aria-hidden')
      }});
      element.setAttribute('inert', '');
      element.setAttribute('aria-hidden', 'true');
    }
    emit('rwa:splash-shown', 'mounted');
    // A broken or indefinitely stalled bootstrap must not hide its status forever.
    // This only removes the cover; it NEVER marks the application ready or
    // enables any controls. The original loading/error state remains in charge.
    watchdogTimer = setTimeout(() => exit('watchdog'), Math.max(45000, minimumMs + 5000));
    if (settled || root.dataset.rwaInitialization === 'settled') onSettled();
    else minimumTimer = setTimeout(() => { if (settled) exit('settled'); }, minimumMs);
  }

  document.addEventListener(SETTLED, onSettled);
  window.addEventListener('error', onScriptError, true);
  // 'interactive' is reached when HTML has been parsed, before deferred module
  // downloads finish. Start the hold then, not after waiting for module loading.
  function onDocumentReady() {
    if (document.readyState !== 'loading') {
      document.removeEventListener('readystatechange', onDocumentReady);
      mount();
    }
  }
  if (document.readyState === 'loading') document.addEventListener('readystatechange', onDocumentReady);
  else mount();
})();
