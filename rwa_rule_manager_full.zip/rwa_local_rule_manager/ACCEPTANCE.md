# Acceptance and remaining gates — v5

## Local development gates

Run from the source package:

```bash
python build_command_patterns.py --check
node tests/run_all.mjs
python tools/build_standalone.py
python tests/browser_test.py --mode dom
```

Current local checks are recorded in reports/release_summary.json, not assumed from a previous version. Compiler validation/failed-build atomicity, numeric and temporal normalization, longest phrase precedence, bounded fuzzy recovery/refusal, actual routing, state commit/cancellation/stale checks and accounting regressions are covered. Clean comparison runs fuzzy ON and OFF; conversations requiring a deliberate typo are not mislabeled clean controls.

The known 626-question set contains partial expected slots; it cannot certify full-parameter exact match. The newer 225-question set includes complete gold for 159 supported commands: every one of the 25 flattened command parameters is declared, including explicit absence. Top-1 intent alone is not sufficient. Actual execution success is reported separately. A correctly parsed but unavailable period must not return an old report.

The six documented legacy text/context differences from v3 remain explicit, with raw failures retained. Their expected safer behavior is separately validated. Do not delete failing old results to manufacture a clean test history.

## No blind claim

The shipped sets are developer-authored, exposed and used during fixes. They are not independently sampled bank conversations. The holdout template is empty, and guard self-tests are synthetic integrity checks, not generalisation evidence. An independent owner must freeze code before writing/presenting the new set. Exposure followed by tuning retires it.

The preserved MiniLM app has fewer features and observable slots. Missing parameters cannot establish what its internal model understood. Require the same commands, all required parameters, supported/unsupported outcomes, dialogue and data for a fair bank-specific evaluation; report missing baseline observability rather than 0% intrinsic MiniLM ability.

## Gates still open for production

- Bank governance classification and AI-assisted development policy.
- Real approved Tableau/SSO/SharePoint origin, CSP/CORS/MIME, refresh/race/data-truncation behavior.
- Server-side row permissions including JSON payloads, catalog visibility and group switches.
- Similar-name/alias safety review with the actual customer catalog.
- Actual data-unit definitions and additive, non-overlapping driver decomposition.
- Independent full-gold holdout and adversarial user acceptance at bank scale.
- Security/penetration/egress/resource exhaustion tests and dependency review.
- Operational deployment, signing/hash origin trust, ownership, rollback, monitoring.

The local browser's HTTP navigation attempt was blocked by administrator policy. In-memory HTML tests do not close these gates; no workaround was used to bypass that policy.

## Known functional limits

Only approved historical English RWA reporting; single-word typo recovery, no dates/amounts auto-correction; bounded numbers and periods; USDm money filtering; explicit percentage/rate capability for ratio filters; no currency conversion, negative-magnitude thresholds, arbitrary Boolean/nested constraints, forecasts, credit recommendations or rating-event causal explanation. Current quarter includes all three months. Unavailable data is not silently truncated or imputed. A caller must not treat manual fit as a calibrated probability.
