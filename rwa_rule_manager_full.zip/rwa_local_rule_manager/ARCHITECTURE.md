# v5 production-path architecture

This is an incremental v4 extension, not a parallel demo parser. Both pre-fetch routing and the answer parser call the same lexical typo recovery. UI, Tableau adapter, row contract, state commit, confirmation and existing arithmetic remain in the actual application path.

| Stage | File | Contract |
|---|---|---|
| Original text and normalization | `semantic/text.js` | Original retained; NFKC/case/possessive/contraction normalization; format-control rejection |
| Longest phrase, dictionary and aliases | `semantic/dictionary.js` | Leftmost-longest literal phrase resolution; exact-name shielding; no guessed collisions |
| Safe fuzzy | `semantic/fuzzy.js`, `lexical.js` | Unknown tokens → bounded OSA edit distance → reviewed candidate; exact, number, unit and temporal material protected |
| Typed number/unit | `semantic/numbers.js` | Raw + base-unit value + operator + executor-basis conversion |
| Temporal | `semantic/periods.js` | Month/quarter/window with explicit analysis anchor and spans; no clock-dependent substitution |
| Slots | `semantic/slots.js` | Identities, scope, metric, topN, thresholds, periods, references |
| Relations/negation | `semantic/relations.js` | Compared pair vs excluded identities vs threshold complement; unsafe negation refused |
| Named features | `semantic/features.js` | Human-defined semantic coordinates; no latent embeddings |
| Manual fit and contradictions | `semantic/scoring.js` | Positive weighted evidence minus contradictory features; all candidate scores computed |
| Command grammar | `semantic/grammar.js` | Explicit grammar ID and required relationships checked per command |
| Constraints/ambiguity/unsupported | `semantic/validation.js` | Required/optional/forbidden slots; margin, unsupported concepts, unmatched content |
| Tentative context patch | `semantic/followups.js` | Finite projection needed for inherited-slot validation, never a premature state commit |
| Command and explanation | `semantic/engine.js` | Validated existing executor plan plus audit; no financial facts generated |
| Data route | `semantic/routing.js` | Same typo recovery, actual group IDs, authorised fresh provider requests |
| Preview/confirmation | existing `rule_client.js`, `app.js` | No successful state from cancellation/error/stale preview; debug opt-in |
| Calculation/templates | existing `rwa_engine.js` | Aggregate recorded rows; report facts; state stores parameter allowlist and ID-only refs |
| Failures | `semantic/diagnostics.js`, `tools/failure_analysis.mjs` | Failure disposition, layer hints, per-field mismatches; expected refusals separate |

## Phrase and typo semantics

At a given start position, the longest valid dictionary phrase wins. When valid phrases overlap with different starts, leftmost consumes first. This declared deterministic choice is tested, not a claim of universal linguistic optimality. Exact identity collisions stop before fuzzy. Case/punctuation/possessives normalize before matching. A known exact token is not 'improved' by fuzzy.

Fuzzy similarity is `1 - editDistance / max(lengths)`. Adjacent transposition counts as one. Length/edit/threshold/margin/category limits are manually configured. Only single-word reviewed candidates are indexed, then final grammar/constraints still apply. Numeric/money/date text is not auto-corrected; date-like detection can protect a token without changing it. A lexical correction accepted flag does not mean the query was executed. The final explanation also records `validatedCommand`.

## Scoring and context

Positive evidence is the sum of explicit match strength × manual component weights. Contradiction weights are negative; available positive components normalize the fit. A rule-fit of 0.93 is not a 93% probability. No learned calibration occurs. A high score cannot override invalid grammar, unknown concepts, an ambiguous identity, missing required slots or unsupported modifiers. An invalid top candidate cannot silently turn into an unrelated report.

Context projection is necessary before slot-completeness checks, but committed state changes only after successful confirmed execution. A follow-up period uses the last executed report month; a fresh request uses explicit/visible Tableau context. Reset/invalidation and context-basis rules remain. Result numbers are never input to another target's parse or facts.

## Canonical values versus executor units

Example: `25 million` → `{canonicalValue:25000000, unit:'absolute'}` → existing USDm filter value 25. `10 percent` → ratio 0.1 → existing percentage-points filter value 10. Both raw and converted values are traced. IEEE-754 numeric arithmetic and the existing tolerances remain; this is not a decimal settlement library.

`12m` is protected as money within a ranking bound; in `trend over 12m` it is a reporting window. No generic fuzzy edits are permitted in either case. Bare thresholds need a unit, currency marker, or strict grouped base-amount syntax; malformed grouping, >safe representable magnitude, unsupported signs/ranges, unknown units and invalid dates stop execution.

An explicit numeric filter with AUTO direction acts on **signed values**, rather than allowing the sign of unrelated portfolio net movement to hide qualifying rows. Explicit decline-magnitude/absolute-magnitude bounds are still refused. Existing aggregation/driver formulas were not replaced.

## Preserved boundary and limitations

`tableau_adapter.js`, `csv_adapter.js`, `network.js`, `group_catalog.js`, `styles.css`, `rule_client.js`, original configuration/catalog/sample bytes are preserved; hashes are in `reports/source_diff.json`. Existing RWA arithmetic is reused. Changes in `rwa_engine.js` add distinct direction-check/amount/balance reporting and repair AUTO-threshold sign selection. `app.js` adds a direction-check label/preview and hides debug by default.

No unrestricted SQL/JS/regex, learned embeddings, knowledge-graph inference, causality discovery or runtime rule mutation is added. Product/location ranking still needs source grain; two-subject × two-period matrix, driver-filtered comparisons and arbitrary Boolean logic remain unsupported. Independent bank governance classification, data permissions and deployment validation remain required.
