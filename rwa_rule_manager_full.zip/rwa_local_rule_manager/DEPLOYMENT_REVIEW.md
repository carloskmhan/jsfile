# Release review — incremental v5

This package upgrades the supplied v4; it is not approval to put bank data into a new environment. The independent-review questions are:

1. Is this manually configured grammar/feature/scoring/string-matching reporting application in scope under the bank's actual AI and model/tool policy? No exemption is asserted.
2. Are the allowed analyses, filters, directions, units and language limitations approved, including signed bounds and explicit negative propositions?
3. Are source data, row permissions, dependencies, hosting/CSP/CORS/SSO and actual network requests verified?
4. Is there a controlled CSV rule change workflow with independent gold cases, review and rollback?

## Scope and changes

The developer used ChatGPT to modify existing source and tests. Runtime does not call it. New fuzzy/number/temporal/grammar modules are called by the actual routing/parser path. No learning or embedding model is shipped. The optional development MiniLM comparison uses a separately preserved original package, not a production dependency.

A request is not executed merely because its best score is highest. Invalid grammar, unknown/unsupported concepts, low fit/margin, ambiguous identities, missing fields or forbidden conditions stop the command. Explicit user confirmation is retained; this is a usability/error-control step, not legal assurance that the application is 'non-AI'.

## Current classification and deployment status

Version 5.0.0-review. Production-like build; bank governance/security approval and real hosting validation **not completed**. No external reviewer-owned blind set was provided. Developer regression scores must not be presented as independent accuracy, 99% MiniLM equivalence or universal language superiority. Read BENCHMARK.md before using any comparison numbers.

Default liveReviewAcknowledged remains false. Only an authorised administrator should change it after the actual applicable reviews. Preserve existing approved Tableau URLs, filters, units and credentials flow. Do not use the synthetic catalog/financial fixtures as bank truth or host developer validation files in the production folder.

## Reviewable artifacts

- `reports/source_diff.json`: original v4/current hashes.
- `BUILD_INFO.json`, `SHA256SUMS.txt`: current runtime inventory.
- `reports/release_summary.json`: current measured local tests and explicit limitations.
- `reports/robustness.json`: complete command parameters, refusals and post-parse data failures.
- `reports/failure_analysis.json`: failure layers and expected refusal diagnostics.
- `reports/holdout_status.json`: no blind evaluation performed.
- `CISO_SECURITY.md`, `ACCEPTANCE.md`: outstanding operational gates.
