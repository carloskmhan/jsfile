# v4 → v5 migration

**Do not overwrite only command_patterns.txt when upgrading.** v5 adds runtime modules and schemaVersion 5. The v5 loader refuses v4 artifacts explicitly. Stage the full web package in a new folder; keep the previous release and approved bank settings for rollback.

## Preserve existing integration

Keep the current Tableau URL, classic API script address, worksheet, filter and field mapping, catalog location, origin allowlist, source limits, unit and reconciliation tolerance. These defaults are not replaced with real bank credentials. Never add credentials to a CSV or downloadable web source.

The data contract remains:

```text
client_group_id | client_group_name | group_location | json_data
```

Do not replace production data with the synthetic CSV/catalog. `aliases.csv` must bind to actual approved IDs and parent relationships; aliases do not grant access. Tableau server row-level permissions must constrain data inside the returned JSON, not merely displayed labels.

The following are byte-identical to the full v4 source: `tableau_adapter.js`, `csv_adapter.js`, `network.js`, `group_catalog.js`, `styles.css`, `rule_client.js`, `tableau_config.txt`, `rwa_sample_data.txt`, `tableau_sample.csv`. Verify current hashes in `reports/source_diff.json`. NLP module changes and limited reporting/filter changes are documented rather than claimed unchanged.

## Merge existing custom rules

1. Copy the v5 source into staging. Preserve all v4 CSV edits in a backup.
2. `commands.csv` now needs a valid `grammar` value for each existing action. Use the shipped same-action example as a reference; do not invent a grammar/action pair.
3. Merge approved custom synonyms/aliases/followups into the v5 schemas. Add the three new CSVs: fuzzy_config, units, temporal. Retain settings and review new defaults.
4. Compile and run tests. Compiler failure must leave the old generated file intact.
5. Stage the full web runtime, test UI/SSO/provider/reloads and permissions, then approve deployment. After this full migration, ordinary rule-only edits can again ship generated command_patterns.txt only.

## Observable changes

- Safe typo fallback now runs in pre-fetch routing **and** final interpretation. No new groups are manufactured.
- Numeric/unit/date literals are typed and never corrected by fuzzy. Relative dates use context, not system today.
- A ranking numeric filter with no direction applies to signed values, independent of the unrelated portfolio net sign. Explicit unsupported decline/absolute magnitude thresholds still fail safely.
- RWA yes/no direction checks are distinct from causal attribution reports. Amount questions use a shorter template. Negative direction checks label the checked proposition.
- Normal UI hides detailed debug; add `debug: true` only in an approved developer configuration. Preview still shows all execution parameters.
- The six documented v3→v4 safer behavior differences remain; raw legacy reports retain them. No regression expectation was erased merely to show 100%.

## Operational checks

```bash
python build_command_patterns.py
node tests/run_all.mjs
python tools/build_standalone.py
node serve.mjs
```

Web deployment still requires HTTPS/static hosting and its actual CSP, module MIME, CORS and Tableau configuration. The current environment's browser blocked local HTTP navigation by administrator policy. No policy bypass was used; local DOM tests do not certify real bank hosting. Approval flags are configuration acknowledgements, not authentication.

Default live mode is locked as before. The source package contains development tests and optional preserved-baseline A/B tools; deploy only the web subset. Neither ZIP includes a MiniLM model. A/B consumes the separately preserved original package only in an approved development environment.
