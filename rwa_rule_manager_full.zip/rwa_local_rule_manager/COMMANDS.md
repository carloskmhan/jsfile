# CSV rule maintenance — v5

CSV files are the only canonical human-managed rule source. The runtime reads the generated `command_patterns.txt` once. The initial header is stripped by the v5 JSON loader; do not call bare JSON.parse on the full header text or mix v4 rules with v5 code.

## Files and editable semantics

`commands.csv`: one row per approved operation. Existing columns retain intent/action/response template, scope, primary/supporting/contradiction features, required/optional/forbidden slots, component weights and minimum fit/margin. New `grammar` selects an existing finite grammar ID, not a regular expression. Pipe separates lists. Do not put JSON or executable expressions in cells. An action or feature not implemented in `tools/rule_schema.py` needs reviewed source changes.

`grammar` values include MOVEMENT_REPORT, MOVEMENT_CHECK, DRIVER_AMOUNT, DRIVER_CHECK, ENTITY_AMOUNT, RANKING, COMPARISON, HISTORY, RECONCILIATION, OFFSETS, CONCENTRATION and MAIN_DRIVER. A comparison needs two subjects or two periods or an explicit supported peer context. Ranking has a rankable dimension and bounded N; omitted N uses configured default 5 and is shown in preview. Required slots are still checked separately.

`synonyms.csv` contains concept,phrase,weight,enabled,notes. Multi-word phrases are literal, longer at the same start takes precedence. For example, ROOT / what drove and INCREASE / went up do not require full-question templates. Avoid synonyms that discard an exclusion or reverse a comparison. Existing longer phrases may overlap intentionally; the compiler records overlap and precedence. Equal token sequences with conflicting concepts are rejected.

`aliases.csv` contains kind,canonical_id,canonical_name,parent_id,alias,enabled,notes. GROUP and ENTITY identities are bound to actual catalog/data IDs. SEC is not automatically reassigned to a group if your catalog identifies it as an entity. Collision or unknown identity does not create a new client. ID columns must remain text.

`followups.csv` retains finite scope/period/filter/reference patches. Change an expression by linking to an existing patch; do not create unrestricted captures. All captured slots and target slots are validated. Successful old parameters + patch = new parameters, with fresh data. No old result values are carried into new facts.

`settings.csv` retains manual weights/limits/state policy. `inherit.result=never` and zero ignored unknown-content tokens cannot be weakened. Threshold/margin values are rule-fit settings, not statistical probabilities.

## Fuzzy configuration

```csv
category,min_length,threshold,max_edits,min_margin,max_corrections,enabled,notes
semantic_word,5,0.80,1,0.08,2,true,Unknown semantic word only
entity,5,0.83,1,0.08,1,true,Single-word reviewed CSV alias only
short_word,0,1.00,0,0.10,0,false,No short-token fuzzy
```

Category settings differ intentionally. Compiler safety floors require min length ≥5, threshold ≥0.80 semantic/≥0.83 identity, margin ≥0.05, bounded edits/corrections, and disabled short-word correction. Raising thresholds reduces typo acceptance; lowering them cannot bypass these guards. Defaults have only developer regression evidence, not independent optimality. In v5, numeric/temporal/unit/negation words and short acronyms are protected; no fuzzy model selects an intent. An accepted candidate must still be supported by other exact evidence or valid follow-up context.

`Samsng` can recover a known single-word Samsung alias; unlisted new clients and ambiguous near names are refused. Multi-word alias spelling recovery is not supported yet. Test ordinary clean questions before/after any changes, not just positive typos.

## Numbers and units

`units.csv`: phrase,kind,multiplier,enabled,notes. kind is absolute or ratio. Standard meanings cannot be redefined: k=1000, m/mn/million=1e6, bn/billion=1e9, percent/%=.01, bps=.0001. Unknown kinds/scales and unsafe syntax are rejected.

Typed number grammar supports integers, strict 3-digit comma groups, decimal notation, zero–nineteen, tens with one digit (e.g. twenty-five), one hundred. Top N is capped at the configured bound. Units cannot be corrected by spelling similarity. `25,000,000` is base currency units; `25m` is a million multiplier. A bare `25` is intentionally insufficient for a money threshold. Currency conversions and scientific notation are not implemented.

Ratio conditions require percentage-change capability. Bps requires an explicit percentage metric; 25 bps is 0.25 percentage points, not 25 USDm or a balance deduction. Double precision and existing financial tolerances apply.

`above`/`greater than` mean strict GT, `at least` means GTE, `below`/`less than` mean LT, `at most`/`no more than` mean LTE. The finite `excluding groups below 25m` relation means GTE, including the boundary. Arbitrary NOT/OR/nested conditions are not invented.

## Temporal source

`temporal.csv`: phrase,kind,value,enabled,notes. MONTH 1–12; RELATIVE_MONTH -1 or 0; RELATIVE_QUARTER -1 or 0; YTD 0. Standard month aliases cannot be mapped to another month. ISO month, quarter notation and N-month range syntax are fixed typed grammars. Current quarter is the entire quarter. Last-N windows end at the effective analysis anchor; diagnostics identify the anchor source. Missing time data never becomes zero or the latest month.

## Compiler checks and atomic output

```bash
python build_command_patterns.py
python build_command_patterns.py --check
```

The compiler validates IDs, lists, fields, finite ranges, known concepts/slots/action/grammar/response references, conflicts, alias/parent relationships, follow-up captures, overlapping token sequences, units, month values and fuzzy safety. Overlaps with declared deterministic precedence are audited, not all rejected; indistinguishable conflicting phrases are rejected. User-supplied regex is forbidden rather than compiled for execution.

It writes a temporary file and flushes it before replacement, only after all validation succeeds. A failed compile keeps the existing approved artifact. Keep a versioned backup and normal filesystem permissions; atomic replacement is not deployment authorization or a cross-platform backup system. Browser runtime does not consume the CSVs directly.

After the first full v5 migration, most rule-only changes require deployment of the new generated `.txt` and app reload. A standalone demo embeds rules and must be regenerated with `python tools/build_standalone.py`. The HTML editor is only a maintenance notice.

## Regression and independent evaluation

Edit `tests/questions.csv` for existing partial-gold regression or `tests/robustness.csv` for complete-gold v5 cases. The latter has `exact_gold=true`, every expected command field populated, and `~` for absence. Its generator `tests/create_robustness.py` contains hand-specified developer expectations; rerunning it replaces the shipped regression CSV, so retain custom cases in a separate file.

```bash
node tools/evaluate.mjs tests/my_regression.csv reports/my_regression.json
node tools/failure_analysis.mjs reports/my_regression.json reports/my_failures.json
```

Never turn a reused or tuned-on set into 'blind' by changing its label. `tests/holdout_template.csv` is empty. See BENCHMARK.md for the external-review freeze/seal workflow. No reviewer-owned holdout was provided with this release.
