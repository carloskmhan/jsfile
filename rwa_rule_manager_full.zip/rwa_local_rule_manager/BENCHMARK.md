# Measured developer evaluation — v5

**Not a blind holdout, not an independent bank accuracy estimate, and not evidence of universal MiniLM superiority.** The new cases were written by the developer and used while fixing code. An empty holdout template and manifest checks do not establish generalisation.

## 1. Corpora and exactness

- Known v4 regression: 626 developer-known questions. Gold assertions are partial, so do not call all 626 complete-command exact matches.
- New robustness set: 225 developer-known cases, including 159 supported commands with **25 explicitly stated gold parameters** each, 64 unsupported cases and 2 ambiguity cases. Every expected absent value uses `~`; omitted gold fields fail validation for `exact_gold=true`.
- Clean ON/OFF controls: 830 cases retained after excluding entire conversations that deliberately require typo recovery. Clean supported commands must be identical; hard negatives must remain rejected by both. 830/830 preserved the tested outcomes. This is not a new independent test population.
- Direct production-module tests and browser tests are separate checks, not extra independent language examples.

Full command exact-match is command plus all declared parameters, including IDs, period, metric, direction, N, driver, exclusions, comparison targets, threshold/operator/canonical unit, dimension, candidate sets, check mode, negation, peer/style/response variant. It measures the command contract before execution, not all possible financial correctness. In the new set **147 supported plans produced answers and 12 were stopped for missing period data**. Those 12 must not be advertised as completed financial answers. Execution guards reuse original numerical functions; independent numerical assertions are in direct/legacy tests.

## 2. v5 current regression metrics

| Metric | Result | Scope |
|---|---:|---|
| Intent | 159/159 | Supported cases |
| Identity fields | 477/477 | Group/entity/comparison field assertions |
| Period | 159/159 | Supported cases |
| Number/unit | 636/636 | N/value/canonical value/unit assertions, including absence |
| All declared slots | 3975/3975 | Assertions, not question count |
| Relation fields | 477/477 | Pair/exclusion assertions |
| Negation/modifier | 636/636 | Declared field assertions |
| Follow-up full command | 7/7 | 7 accepted later turns; other context checks separate |
| Unsupported rejection | 64/64 | Rejected developer cases |
| Ambiguity handling | 2/2 | Two corpus cases; direct alias ambiguity checks also exist |
| Positive typo recovery | 17/17 | 17 supported typo questions, including 3 identity typos |
| Identity typo full command | 3/3 | Small 3-case subset, not catalog-wide accuracy |
| Fuzzy false-positive command rate | 0/20 | 20 negative/adversarial typo-context cases |
| Overall false-positive command rate | 0/66 | All 66 expected rejection/ambiguity cases |
| Full command exact-match | 159/159 | 159 complete-gold supported requests |

Node parsing measurements are in reports/robustness.json: p50 1.065 ms, p95 1.845 ms on this execution. These are warm/local parseQuestion timings excluding provider/UI/network. They are not a bank service-level commitment.

## 3. Actual preserved MiniLM comparison

The original `rwa_tableau_v2` package was retained separately. Its original INT8 ONNX, tokenizer, pooling, classifier and Conversation code executed in Chromium 144.0.7559.96. No model retraining or replacement took place. There were 39/39 exact token fixture matches; maximum observed embedding difference was 0 across those fixtures. This checks the adapter on those fixtures, not arbitrary model correctness.

The same 225-case corpus, stated contexts, synthetic data and free-running conversations were supplied to both applications. Gold parameters were not supplied to either parser or used to repair intermediate state. Source hashes and raw outputs are stored in reports/ab_results.json.

| Observable outcome | v5 | Preserved MiniLM application |
|---|---:|---:|
| Selected intent on 159 supported cases | 159/159 | 89/159 |
| Unsupported requests refused | 64/64 | 11/64 |
| Complete gold command | 159/159 | Not fully observable |
| Warm parse p50 in same Chromium | 1.000 ms | 24.400 ms |
| Warm parse p95 in same Chromium | 1.700 ms | 100.200 ms |

**Do not equate old output omissions with 0% intrinsic MiniLM language ability.** The original app exposes only a subset of the required slot contract and lacks newer actions. Its observable slot matches were 788/954, with 3021 unobservable assertions. Raw required-contract conformance counts missing fields as non-verified, but primary full-command/follow-up/typo exact-match metrics are marked NOT_FULLY_OBSERVABLE, not a substantive 0% accuracy claim. A newly enhanced MiniLM app could use the same arithmetic, state and validation functions.

Timing uses serial pages in the same Chromium process. MiniLM parse includes embedding plus its intent logic; v5 parse includes lexical/scoring/validation. Asset transport uses in-memory test injection, not real HTTP hosting. Initial engine setup was 33.200 ms for v5 and 448.800 ms for the baseline, but the respective startup work differs. Injection+initialization values include Python/browser transfer and must not be called production model-download time. CDP JS heap snapshots are included, but native/WASM/total-process/peak memory and bank network cold-load time were **not measured**. No memory or production-startup superiority is certified.

## 4. Failure analysis and development exposure

`reports/robustness_initial.json` preserves the first 218/222 result: a cross-group exclusion was silently ineffective and the date protection initially rejected `decrese`-like words. Both were fixed. Legacy replay then identified concentration/trend yes-no wording being over-broadly interpreted as a plain movement check; its predicate rules were narrowed and three cases added. Additional direct tests exposed the `trend over 12m` role collision and signed threshold behavior on a net-declining portfolio. These were corrected and retested. The clean-control evaluator originally included an intentional typo conversation; it now excludes whole typo-dependent conversations from clean comparison, with exclusions listed.

These interventions make the set explicitly **development regression**, not untouched holdout. `reports/failure_analysis.json` separates genuine mismatches from expected refusals. Six old v3 textual/context expectations still differ by documented safer policy; reports/migration_tests.json retains the raw outcomes and explanations.

## 5. Independent reviewer workflow — not run in this release

No reviewer-owned blind data was supplied. reports/holdout_status.json has status NOT_RUN and accuracy null. Do not invent a blind set after knowing the implementation and label it independent.

```bash
# Freeze before receiving independent questions/gold.
python tools/holdout_guard.py freeze --snapshot reports/frozen_runtime.json
# Reviewer writes a new corpus with complete gold and split=holdout.
python tools/holdout_guard.py seal --snapshot reports/frozen_runtime.json \
  --corpus tests/private_holdout.csv --manifest reports/holdout_manifest.json --reviewer NAME
# Rule-only evaluation.
node tools/evaluate.mjs tests/private_holdout.csv reports/holdout_results.json \
  --require-holdout --holdout-manifest reports/holdout_manifest.json
# Same corpus to both apps, original baseline retained locally.
python tools/ab_minilm.py --baseline-dir /approved/original/rwa_tableau_v2 \
  --corpus tests/private_holdout.csv --require-holdout \
  --holdout-manifest reports/holdout_manifest.json --out reports/holdout_ab.json
```

The guard requires unchanged runtime/rules/data hashes, unchanged corpus, complete expected parameters and no normalized overlap with shipped development sets. The reviewer's ownership and actual blindness remain human attestations; hashes cannot prove them. If failures inform any rule/weight/threshold changes, retire that corpus for generalisation and ask for a new independent set. Include near-opposites, typos and clean controls, real permissions/data failures and free-running follow-up chains. No auto-tuning or learned threshold selection is implemented.
