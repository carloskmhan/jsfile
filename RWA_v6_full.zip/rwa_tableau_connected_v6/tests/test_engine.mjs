/** v6 ID/catalog/context regression entry point. Original v5 cases retained in validation_history/v5_test_engine.mjs.txt. */
import "./connected_tableau.mjs";
