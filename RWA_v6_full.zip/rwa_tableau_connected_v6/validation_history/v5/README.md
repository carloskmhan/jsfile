Historical v5/v3 regression and A/B records from the original package. NOT v6 measurements. Current reports are under reports/. Model assets remain external and are not included.
