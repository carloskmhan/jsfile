"""Developer-authored synthetic tests for builder v1.0.6."""
import copy, csv, json, tempfile, time, unittest
from decimal import Decimal
from pathlib import Path
from build_tableau_csv import build, DataError, parse_month, decimal_value

ROOT=Path(__file__).resolve().parent
BASE_CONFIG=json.loads((ROOT/'data_mapping.json').read_text())
with (ROOT/'raw_sample_SYNTHETIC.csv').open(encoding='utf-8-sig',newline='') as f:
    BASE_ROWS=list(csv.DictReader(f))

class BuilderTests(unittest.TestCase):
    def setUp(self): self.temp=tempfile.TemporaryDirectory(); self.p=Path(self.temp.name)
    def tearDown(self): self.temp.cleanup()
    def run_build(self, rows=None, cfg=None, unit='base', currency='USD'):
        rows=copy.deepcopy(BASE_ROWS if rows is None else rows); cfg=copy.deepcopy(BASE_CONFIG if cfg is None else cfg)
        with (self.p/'raw.csv').open('w',encoding='utf-8-sig',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
        (self.p/'cfg.json').write_text(json.dumps(cfg),encoding='utf-8')
        result=build(self.p/'raw.csv',self.p/'cfg.json',self.p/'output',unit,currency)
        with (self.p/'output'/'tableau_data.csv').open(encoding='utf-8-sig',newline='') as f: out=list(csv.DictReader(f))
        return result,out
    def payload_rows(self,out): return json.loads(out[0]['json_data'])['rows']

    def test_basic_output(self):
        r,out=self.run_build(); rows=self.payload_rows(out)
        self.assertEqual(r['input_rows'],6); self.assertEqual(len(rows),2)
        self.assertEqual(sum(x['rwa_curr'] for x in rows),1570)
        self.assertEqual(sum(sum(x['drivers'].values()) for x in rows),270)
        self.assertEqual(sum(x['rwa_prev'] for x in rows),1300)
    def test_ids_keep_leading_zeroes(self):
        _,out=self.run_build(); self.assertEqual(out[0]['client_group_id'],'000001'); self.assertEqual(self.payload_rows(out)[0]['entity_id'],'00001001')
    def test_dynamic_driver_retained(self):
        rr=copy.deepcopy(BASE_ROWS); rr[0]['detail_driver']='New dynamic driver (test)'; _,out=self.run_build(rr); self.assertIn(rr[0]['detail_driver'],self.payload_rows(out)[0]['drivers'])
    def test_current_attributes_retained_previous_ignored(self):
        _,out=self.run_build(); a=self.payload_rows(out)[0]['attributes']
        self.assertEqual(a['ead_curr'],1500); self.assertEqual(a['cg'],'8'); self.assertEqual(a['scorecard_curr'],'CORPORATE')
        self.assertNotIn('ead_prev',a); self.assertNotIn('prev_cg',a); self.assertNotIn('previous_contexts',a)
    def test_prev_fields_can_all_differ_without_error(self):
        rr=copy.deepcopy(BASE_ROWS)
        for i in [0,1,2]:
            rr[i]['prev_group']=f'OLD {i}'; rr[i]['prev_group_code']=f'PG{i}'; rr[i]['prev_cg']=str(1+i); rr[i]['prev_ead']=str(1000000000+i*10000000); rr[i]['prev_rwa']=str(800000000+i*10000000); rr[i]['prev_scorecard']=f'OLD_SC_{i}'
        _,out=self.run_build(rr); row=self.payload_rows(out)[0]
        self.assertEqual(row['rwa_prev'],row['rwa_curr']-sum(row['drivers'].values()))
    def test_prev_rwa_column_can_be_missing_from_mapping(self):
        cfg=copy.deepcopy(BASE_CONFIG); cfg['columns']['rwa_prev']=None
        rr=copy.deepcopy(BASE_ROWS)
        _,out=self.run_build(rr,cfg); self.assertTrue(self.payload_rows(out))
    def test_exact_driver_impact_pair_repeat_is_deduplicated(self):
        rr=copy.deepcopy(BASE_ROWS); rr.append(copy.deepcopy(rr[0]))
        _,out=self.run_build(rr); row=self.payload_rows(out)[0]
        self.assertEqual(row['drivers']['EAD Increase (STD)'],200)
        self.assertEqual(row['attributes']['duplicate_attribution_rows_ignored'],1)
    def test_same_driver_different_impact_is_additive(self):
        rr=copy.deepcopy(BASE_ROWS); extra=copy.deepcopy(rr[0]); extra['RWA Diff by driver']='50000000'; rr.append(extra)
        # To preserve current snapshot consistency, current RWA is unchanged; derived prev RWA simply follows unique bridge total.
        _,out=self.run_build(rr); row=self.payload_rows(out)[0]
        self.assertEqual(row['drivers']['EAD Increase (STD)'],250)
        self.assertEqual(row['rwa_prev'],row['rwa_curr']-sum(row['drivers'].values()))
    def test_detail_driver_plus_impact_uniqueness_ignores_prev_context(self):
        rr=copy.deepcopy(BASE_ROWS); extra=copy.deepcopy(rr[0]); extra.update({'prev_group':'DIFFERENT','prev_group_code':'OTHER','prev_cg':'999','prev_ead':'1','prev_rwa':'2','prev_scorecard':'X'}); rr.append(extra)
        _,out=self.run_build(rr); row=self.payload_rows(out)[0]
        self.assertEqual(row['drivers']['EAD Increase (STD)'],200); self.assertEqual(row['attributes']['duplicate_attribution_rows_ignored'],1)
    def test_current_rwa_inconsistency_still_fails(self):
        rr=copy.deepcopy(BASE_ROWS); rr[1]['RWA']='1250000001'
        with self.assertRaises(DataError): self.run_build(rr)
    def test_current_scorecard_inconsistency_still_fails(self):
        rr=copy.deepcopy(BASE_ROWS); rr[1]['Scorecard']='DIFFERENT'
        with self.assertRaises(DataError): self.run_build(rr)
    def test_duplicate_client_name_distinct_leid_allowed(self):
        rr=copy.deepcopy(BASE_ROWS); rr[3]['client name']='Samsung Electronics'; _,out=self.run_build(rr); rows=self.payload_rows(out); ms=[r for r in rows if r['entity']=='Samsung Electronics']; self.assertGreaterEqual(len({r['entity_id'] for r in ms}),2)
    def test_duplicate_group_name_distinct_id_allowed(self):
        first=copy.deepcopy(BASE_ROWS); second=copy.deepcopy(BASE_ROWS)
        for r in first: r['client group name']='SAME'; r['client group id']='G1'
        for r in second: r['client group name']='SAME'; r['client group id']='G2'
        _,out=self.run_build(first+second); self.assertEqual({r['client_group_id'] for r in out},{'G1','G2'})
    def test_same_group_id_conflicting_name_fails(self):
        rr=copy.deepcopy(BASE_ROWS); rr[1]['client group name']='OTHER'
        with self.assertRaises(DataError): self.run_build(rr)
    def test_same_leid_conflicting_name_fails(self):
        rr=copy.deepcopy(BASE_ROWS); rr[1]['client name']='OTHER'
        with self.assertRaises(DataError): self.run_build(rr)
    def test_missing_driver_fails(self):
        rr=copy.deepcopy(BASE_ROWS); rr[0]['detail_driver']=''
        with self.assertRaises(DataError): self.run_build(rr)
    def test_missing_impact_fails(self):
        rr=copy.deepcopy(BASE_ROWS); rr[0]['RWA Diff by driver']=''
        with self.assertRaises(DataError): self.run_build(rr)
    def test_unsafe_driver_fails(self):
        rr=copy.deepcopy(BASE_ROWS); rr[0]['detail_driver']='__proto__'
        with self.assertRaises(DataError): self.run_build(rr)
    def test_driver_case_spacing_collision_fails(self):
        rr=copy.deepcopy(BASE_ROWS); rr[3]['detail_driver']='ead increase (std)'
        with self.assertRaises(DataError): self.run_build(rr)
    def test_negative_current_rwa_fails(self):
        rr=copy.deepcopy(BASE_ROWS); rr[0]['RWA']='-1'
        with self.assertRaises(DataError): self.run_build(rr)
    def test_unit_and_currency_required(self):
        with self.assertRaises(DataError): self.run_build(unit=None)
        with self.assertRaises(DataError): self.run_build(currency=None)
    def test_number_validation(self):
        self.assertEqual(decimal_value('(1,000.25)','x'),Decimal('-1000.25'))
        for x in ['NaN','Infinity','1,00']:
            with self.assertRaises(DataError): decimal_value(x,'x')
    def test_month_forms(self):
        for value in ['2026-07','2026-07-31','Jul-26','July 2026','Jul2026','202607']: self.assertEqual(parse_month(value,[]),'2026-07')
        with self.assertRaises(DataError): parse_month('July',[])
    def test_explicit_date_format(self): self.assertEqual(parse_month('07/08/2026',['%d/%m/%Y']),'2026-08')
    def test_output_is_not_overwritten(self):
        self.run_build(); p=self.p/'output'/'tableau_data.csv'; before=p.read_bytes()
        with self.assertRaises(DataError): build(self.p/'raw.csv',self.p/'cfg.json',self.p/'output','base','USD')
        self.assertEqual(before,p.read_bytes())
    def test_group_size_limit(self):
        cfg=copy.deepcopy(BASE_CONFIG); cfg['max_group_json_bytes']=10
        with self.assertRaises(DataError): self.run_build(cfg=cfg)
    def test_more_than_50k_raw_rows(self):
        rr=[]
        for g in range(1001):
            for e in range(10):
                for d in range(5):
                    r=copy.deepcopy(BASE_ROWS[0]); r.update({'client group name':f'GROUP {g}','client group id':f'G{g}','client name':f'ENTITY {e}','LEID':f'E{e}','RWA':'105000000','prev_rwa':str(100000000+d),'prev_ead':str(200000000+d),'prev_cg':str(d),'detail_driver':f'Driver {d}','RWA Diff by driver':'1000000'}); rr.append(r)
        r,out=self.run_build(rr); self.assertEqual(r['input_rows'],50050); self.assertEqual(r['entity_month_count'],10010); self.assertEqual(len(out),1001)

if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(BuilderTests); result=unittest.TextTestRunner(verbosity=2).run(suite)
    report={'type':'developer-authored synthetic regression','run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'successful':result.wasSuccessful(),'version':'1.0.6-review'}
    (ROOT/'test_report.json').write_text(json.dumps(report,indent=2))
    raise SystemExit(0 if result.wasSuccessful() else 1)
