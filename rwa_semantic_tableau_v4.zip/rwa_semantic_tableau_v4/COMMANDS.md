# CSV rule maintenance

## Workflow and ownership

CSV is the source of truth. Edit with Excel, LibreOffice or a text editor, save as **UTF-8 comma-separated CSV**, compile, test, review, deploy the generated TXT. UTF-8 BOM and quoted cells are supported. Keep ID columns as text; a spreadsheet must not silently turn long numeric IDs into scientific notation. A `|` joins a short list inside a cell. Do not put JSON, code, regex or formulas in cells. Use `enabled=false` for reviewed disablement; disabled entries do not provide matching rules.

```bash
python build_command_patterns.py
python build_command_patterns.py --check
```

`--check` validates only and does not write. Custom paths are supported:

```bash
python build_command_patterns.py --rules-dir ./rules --out ./command_patterns.txt
```

## commands.csv

Columns:

```text
command_id,intent,action,response_template,scope,
primary_features,supporting_features,contradiction_features,
required_slots,optional_slots,forbidden_slots,
intent_weight,metric_weight,scope_weight,subject_weight,period_weight,modifier_weight,
contradiction_weight,min_confidence,min_margin,enabled,notes
```

- `command_id`: unique ID, referenced by follow-ups.
- `intent`: public semantic intent name; action is an existing executor.
- `response_template`: existing executor/template ID, currently must equal action. This field cannot define executable text or a new calculation. Existing `rwa_engine.js` templates remain the response source.
- `scope`: ANY/GROUP/ENTITY/PORTFOLIO, both scored and constrained.
- features: known explicit coordinate names separated by `|`; no learned vector.
- slots: `metric|subject`, `period|direction|exclusions|concise`, etc. `subject` accepts a group or entity; `entity` specifically requires a legal entity; `comparison` is a supported pair/period/peer comparison. See `tools/rule_schema.py` for the finite vocabulary.
- Typical component weights are 40/20/10/10/5/5. Contradiction weights must be negative (default -40). Weights are manually selected, never fitted.
- Minimum score and margin must be 0–1. Runtime uses the maximum of command `min_margin` and `settings.default_margin`.
- Present named drivers/filters/exclusions/format/candidate sets must be allowed by the CSV and by the executor. Some operations have additional hard safety constraints, so widening CSV slots does not create unsupported behavior.

The primary intent feature must be present. A few matches in default metric/period cannot activate a report. The top candidate must satisfy constraints; the engine does not choose a weaker different command merely because it has fewer missing fields.

## synonyms.csv

```csv
concept,phrase,weight,enabled,notes
ROOT,walk me through,1,true,Ask for recorded movement attribution
INCREASE,went up,1,true,Increase wording
DECREASE,went down,1,true,Decrease wording
COMPARE,difference between,1,true,Explicit comparison
```

These examples already exist in the shipped dictionary; do not duplicate them. Phrase matching is literal, boundary-aware and longest-first. Normalization is NFKC/lowercase, explicit apostrophe/possessive/contraction handling and whitespace folding. Names are shielded before generic vocabulary, so a word inside a client name is not accidentally a date/driver/unsupported intent.

Synonym `weight` (0,1] records a **manual strength**, not a probability. `ROOT` yields the derived feature `RWA_DRIVER` when the relations/other features permit it. Registered `RANK` + entity/group dimension becomes `RANK_ENTITY`/`RANK_GROUP`. Features such as `COMPARE_REQUEST` are explicit derived coordinates in `semantic/features.js`, not encoded hidden parameters.

Do not equate `highest RWA` with `largest increase`, or remove `not`, `excluding`, `percent`, `versus` as courtesy words. `Predict` and other unsupported concepts stop processing rather than reducing the score of a normal report. A new phrase mapped to an existing concept requires only CSV; a genuinely new concept/operation requires reviewed code/schema changes.

## aliases.csv

```csv
kind,canonical_id,canonical_name,parent_id,alias,enabled,notes
GROUP,CG0001,SAMSUNG GROUP,,samsung,true,Use your real approved ID
ENTITY,CG0001-E001,Samsung Electronics,CG0001,sec,true,Entity-specific alias
GROUP,CG0004,TOYOTA GROUP,,toyota,true,Use your real approved ID
```

ID and parent ID bind to the **actual authorised catalog/data**. The compiler rejects conflicting active aliases and duplicate aliases (even for the same target). It does not arbitrarily choose one. Runtime also detects data-level identical names/IDs with different targets and returns `AMBIGUOUS_ENTITY`. Disable or qualify an alias, or use the exact unique ID. `SEC` in this sample means Samsung Electronics, not its entire group.

CSV aliases are canonical. Old `groupAliases`/`entityAliases` in settings no longer add NLP aliases behind the CSV's back. Actual canonical names/IDs remain resolvable. A CSV alias whose ID is absent from the authorised catalog is not an authority to load new data.

## followups.csv

```csv
rule_id,pattern,patch_type,target_slot,command_id,enabled,notes
MY_FOLLOWUP,also analyse {scope},REPLACE_SCOPE,entity,,true,Reviewed new follow-up wording
```

Add this as a new unique rule only after testing. Existing examples include:

- `how about {scope}` → REPLACE_SCOPE
- `and {period}` → REPLACE_PERIOD
- `only those {threshold}` → ADD_FILTER
- `compare {rankref} with {scope}` → COMPARE_REFERENCE
- `what about {driver}` → SET_DRIVER

Slots are typed finite captures: `{scope}`, `{other_scope}`, `{period}`, `{driver}`, `{threshold}`, `{rankref}`, `{n}`, `{metric}`. They do not mean arbitrary wildcards. A group capture only comes from the ID/alias catalog. A number/period capture must pass its own parser. Regex captures, general expressions, JavaScript and SQL are forbidden.

`target_slot` documents the intended patched slot; `patch_type` names the actual reviewed handler. A `CHANGE_COMMAND` references an enabled command ID. New patch algorithms require code review, not just another CSV string.

Explicit suffix periods, exclusions and brevity modifiers can be combined with a matching follow-up. Unsupported or unconsumed suffixes are rejected. No chain of replacement strings invokes arbitrary code.

## settings.csv / inheritance

`inherit.intent/metric/period=inherit`; entity and scope are replaceable. Cross-group entity exclusions and stale result sets are cleared. Driver exclusions may be retained (`inherit.excluded_drivers=inherit`) or reset. The default direction policy is reevaluate on group change, because the new group need not have increased. A fixed threshold may be retained conditionally; changing group clears incompatible entity candidates.

`inherit.result=never` and `unknown_token_limit=0` cannot be loosened by CSV. Only identity references can be reused, with basis checks. No numerical financial result is a context slot.

## Validation / atomic replacement

Validation checks headers, required fields, command IDs, action/template references, concept/slot names, invalid/duplicate phrases, conflicting aliases, finite/ranged weights, min-score/margin, regex-like inputs, follow-up syntax/captures/command IDs, inheritance policy, bounds and resource limits.

All errors identify source file and line where possible. Failed compilation returns nonzero and leaves the existing artifact untouched. Successful compilation writes a sibling temporary file, flushes/fsyncs it, and performs an atomic replace. The runtime file starts with:

```text
# AUTO-GENERATED FILE
# DO NOT EDIT DIRECTLY
# Source: rules/*.csv
# Run: python build_command_patterns.py
```

The following body is JSON. Source hashes are embedded. This makes provenance verifiable against approved sources; it is **not a digital signature or proof of security**. If editing CSV changes meaning incorrectly but remains syntactically valid, review and regression tests must catch it.

## Test examples, not training

Add questions and gold parameters to `tests/questions.csv`, or provide a separate corpus to `node tools/evaluate.mjs`. These are tests, not sources from which weights or rules are automatically learned. A rule improvement after seeing a failed test makes that case a regression case, not unseen validation. Keep a separate, independently authored corpus for acceptance.
