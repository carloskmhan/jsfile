# Security review — v4

**Status: review build, not a security certification, penetration test, AI classification or production approval.**

## What this runtime does / does not do

The deployed code uses manually specified vocabulary, typed slots, finite relations, explicit semantic coordinates, manually chosen scoring weights and context transitions. It invokes existing read-only financial reporting calculations. It has no learned embeddings, ML training, MiniLM/LLM, Transformers.js, ONNX inference, model WASM, telemetry or external AI endpoint. This description does not decide whether the bank categorizes manually scored semantic interpretation as an AI use case. Development was assisted by ChatGPT; development-tool policy is separate from runtime dependencies.

## Implemented controls

- Literal bounded CSV dictionaries/patterns; no arbitrary user regex, SQL, JavaScript, code generation or eval.
- Complete semantic-content checks; unknown/unsupported inputs, ambiguous identities and contradictory conditions stop execution.
- Finite command/slot/executor vocabulary. A high matching score cannot bypass executor constraints. Scores are not probability assurances.
- Compiler diagnostics and atomic file replacement; failed builds preserve the last artifact. Runtime validates shape/version/policy and freezes the loaded registry.
- Authorised catalog binding; aliases do not grant access. Typed identifiers prevent accidentally treating an excluded group as a target.
- Original provider validation for wrong group, malformed/truncated/missing rows, row limits, data grain and finite numbers remains.
- New target data is refreshed. Previous answer values are not inherited. Failed refresh invalidates the active engine/pending preview.
- Preview requires confirmation; cancellations, stale tokens/state/data generations do not create a successful state. This prevents stale UI execution but is not an authorisation mechanism.
- Text outputs use the preserved safe DOM text creation rather than inserting user HTML. History is session memory, not a remote transcript.
- Same-origin configuration/data text loading, approved HTTPS Tableau origins, existing runtime CSP limitations. No remote model fallback.

## Remaining review tasks

Access/RLS is server-side. Browser filters and catalogs are not an access boundary, and every field inside a JSON cell must already be authorised for that user. Dynamic/in-page CSP is not a substitute for a server CSP/header policy and frame-ancestors review. Review all script/frame/connect destinations and SSO redirects in the actual host, and do not relax enterprise browser policies to make embedding work.

The preserved Tableau SDK must be the bank-approved version; its vulnerabilities/support status require normal dependency review. Removing ML reduces deployed model dependencies, not all software risks. A privileged party replacing config/JS/artifacts can change the system; checksums are provenance aids, not signatures. Use change approvals and protected hosting.

Finite input/rule/row bounds are engineering guardrails, not a comprehensive denial-of-service guarantee. Benchmark worst-case alias counts, malformed CSV/data, deeply nested JSON, timeouts and multiple concurrent sessions with the actual portfolio size. Avoid placing secrets in public static config.

## Testing limitations

Local regression/fixtures are not bank access-control, network, SSO, Tableau or SharePoint tests. Managed Chromium blocked localhost navigation with `ERR_BLOCKED_BY_ADMINISTRATOR`. No policy bypass was attempted. In-memory HTML UI tests therefore do not certify HTTP ES-module/fetch loading or server CSP. Optional A/B uses local fixture-injected assets and aborts network requests; this is not a production egress attestation.

Review the weighted semantic engine as a new design even if a previous exact-command tool was accepted. Describe actual functions honestly; renaming it does not alter classification.
