# v4 measured development evidence — not independent validation

## What is measured

The rule sources and tests were authored in this development task. The 626 rows contain repeated grammar cross-products, negatives and five conversations. They are **development/regression**, not independently sampled user language. The first evaluation exposed missing vocabulary and relation bugs; they were fixed and the set rerun. Do not call the final set untouched, blind or representative. The supplied holdout CSV is an empty format only.

Tests compare gold intent/IDs/period/conditions, not just agreement with MiniLM. Blank expected CSV fields are unasserted; `~` explicitly asserts absence. Multi-turn state is free-running and only actual successful executions update state; no expected plan is injected. The rule engine successfully executed all 543 supported cases using the stated fixture. Two synthetic Toyota August rows are appended only by the test loader to test month replacement; the ordinary sample/live data are unchanged.

## Main regression corpus

Total 626; passed 626; failed 0.

Each metric counts only its applicable assertions. Entity accuracy includes group, entity and pair IDs; slot accuracy includes all asserted fields. Follow-up accuracy counts subsequent accepted turns, not conversation initials. Unsupported FPR is accepted negative requests / labelled rejected requests; it is not all possible wrong-answer probability. Ambiguity has a separate status test.

## Real original MiniLM comparator

The original user's `rwa_tableau_v2` is preserved separately. The runner reads its original INT8 ONNX, tokenizer, learned classifier, `rwa_engine.js`, `conversation.js` and `minilm_service.js` implementation. The service embedding/softmax implementation is reused without numerical rewriting; only module bindings and local fixture asset transport are adapted. The original model and classifier are not retrained. Its bundled hashes are checked; 39/39 saved tokenizer fixtures match and maximum embedding difference is 0 on these fixtures. This is finite parity evidence, not proof for all strings.

Both applications ran serially in the same Chromium 144.0.7559.96 version with the same corpus, context and records. The baseline keeps its original rules/conversation logic, not new v4 functionality. It has no general group-pair plan, exclusion filter plan or many newer follow-up capabilities. Therefore this is **a comparison of two existing application implementations**, not intrinsic MiniLM language capability or a best possible MiniLM system.

| Metric | v4 rule | Original MiniLM application |
|---|---:|---:|
| intentAccuracy | 543/543 | 249/543 |
| entityAccuracy | 596/596 | 516/596 |
| periodAccuracy | 543/543 | 539/543 |
| slotAccuracy | 2572/2572 | 1476/2572 |
| followupContextAccuracy | 13/13 | 0/13 |
| unsupportedRejectionAccuracy | 79/79 | 47/79 |
| falsePositiveRate | 0/79 | 32/79 |
| ambiguityHandlingAccuracy | 4/4 | 0/4 |

Important observability qualification: the baseline does not expose metric/direction/exclusion/threshold/pair fields that the v4 plan exposes. The full-slot metric counts missing fields as unmet schema requirements, not a measured numerical mistake in every answer. An auxiliary observed-slot accuracy excludes unobservable fields: 1475/1805 for the baseline. There are 767 unobservable assertions. Do not promote the raw full-plan match difference as “the language model is X times worse”. Baseline raw predictions/prepared questions/answers are retained for audit.

## Latency and memory

Same-browser parsing-stage median: rule **0.50 ms**; original MiniLM preparation + embedding/classifier + parsed fields **9.50 ms**. P95: rule **0.90 ms**, baseline **29.90 ms**. Both exclude Tableau/network/UI confirmation. These are observed synthetic-environment timings, not a production SLA or universal speedup.

Constructor/dictionary binding and MiniLM pipeline initialization are separately recorded. Asset injection includes Python→browser base64/IPC transport and baseline parity work; it is **not network model-load time**. Initial bank web delivery/load is unmeasured. CDP JSHeapUsedSize/TotalSize snapshots are partial managed JS heap, excluding native/WASM/process totals and influenced by fixture duplication and GC. Do not infer a reliable total-RAM advantage from them. See the exact raw timing and memory snapshots in `reports/ab_results.json`.

## Other evidence and limitations

- Compiler: 34/34 preservation/validation tests.
- Engine/state/provider controls: 48/48 tests.
- Original accounting/data regressions: 180/181 original expectations; one deliberately qualified yes/no text difference. Financial reference checks cover 1,162 group-month balances/residuals and 4,634 entity-month records.
- Old dialogue expectations: 56/61; five reviewed safer behavior changes, not hidden. `reports/migration_tests.json` identifies them exactly.
- Browser DOM: same bundled modules and synthetic data in-memory; actual localhost navigation was blocked by administrator. HTTP ES modules, live Tableau, SSO, SharePoint, server CSP and permissions are not certified.

## Independent run procedure

Freeze both implementations; have someone not tuning rules author a new CSV from the supplied schema. Include balanced intents, unfamiliar wording, ambiguity, unsupported metrics and real multi-turn conditions. Supply identical authorised fixtures and context, and assert the complete plan/expected financial result where available. Keep development cases separate.

```bash
python tools/ab_minilm.py --baseline-dir /approved/original/rwa_tableau_v2 --corpus tests/my_holdout.csv --require-holdout --out reports/my_ab.json
```

`--require-holdout` only verifies that rows are labelled `holdout`; it cannot certify that a person did not inspect/tune on them. The runner refuses to download missing models or ignore integrity failures. Optional Playwright and Chromium are development-only. The deployment ZIP excludes the benchmark and all MiniLM assets. A newly improved MiniLM application could reuse the same v4 arithmetic/state safeguards and must be evaluated separately.

No 99% equivalence, universal superiority, governance exemption or production certification is claimed.
