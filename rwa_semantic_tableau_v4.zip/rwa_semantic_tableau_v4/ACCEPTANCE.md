# Acceptance gates

This release is production-like for staged review, not certified production ready.

## Available automated evidence

- CSV compiler diagnostics/atomic preservation tests.
- Engine/state/constraint/provider regression tests.
- Extensible 626-case developer-authored corpus with separately reported intent, identity, period, slots, follow-up, rejection, false-positive, ambiguity and latency metrics.
- Preserved source-data balances and residuals checked against original CSVs.
- Preserved old expectations and explicitly explained behavior changes.
- Chromium in-memory same-app HTML tests for preview/confirm/cancel, group/period change, refresh/no-data, ranking/reference and debug.
- Optional original MiniLM A/B on the same corpus and fixtures, no gold-fed state. Original tokenizer/embedding parity checked. No superiority assumption.

## Must pass before deployment

1. Freeze source/rules and independently collect representative single/multi-turn bank questions, including rejected/ambiguous cases. Record expected full parameters, not just intent. Do not train/tune on this acceptance set and then call it unseen.
2. Review each rule/alias/weight change with intended and near-opposite examples (increase/decrease, balance/change, excluding/checking FX, June/July, group/entity).
3. Test exact bank IDs/catalog, multi-entity grain, all additive-driver definitions, units, coverage, late data, missing months, row truncation and reconciliation residuals.
4. Verify permissions, server-side RLS, each nested JSON record, wrong-group protection, fail-closed refresh, approved query scope and portfolio opt-in.
5. Verify actual HTTP module/fetch/CORS, SSO, Tableau iframe/script SDK, SharePoint headers, server CSP/frame ancestors and no unapproved destinations. The local environment could not perform this.
6. Measure initial delivery/load, p50/p95/worst latency and memory on bank browsers/hardware with actual data/rule sizes. Recorded JS heap is not total process/WASM memory.
7. Obtain internal governance/security/change approval and test rollback. Confirm what “No ML” means under your policy without claiming automatic non-AI status.

## Explicit limitations

The corpus is development/regression data and includes templated cross-products. All supported cases pass after fixing failures observed during development; this is not an untouched holdout or statistical performance guarantee. Only five main corpus conversations (13 subsequent turns) are measured in its follow-up metric; separate legacy and safety suites provide additional scenarios. Four ambiguity cases in the metric are not an exhaustive ambiguity distribution. All numeric facts rely on authorised data, not language understanding.

Six legacy expectations intentionally differ: a clearer negated yes/no answer; four ambiguous-month followups now ask instead of silently selecting the screen month; after the last ranked entity, “next” no longer repeats the last item. The raw legacy reports are retained, with migration tests asserting the exact reviewed differences.

An error in a rule's business meaning can pass CSV syntax checks. A passing hash verifies identity, not safety. Human confirmation does not fix a misleading preview or replace permission checks. Retain separate operational monitoring and feedback/change processes; there is no automatic learning.

Numeric threshold filtering currently requires a USDm basis. Decline/absolute-magnitude threshold conditions are rejected rather than silently mapped to signed-delta comparisons; request those rankings without thresholds.
