# Deployment / governance review record

Release: **4.0.0-review**, manually authored CSV semantic rules.

The application is designed for read-only historical RWA reporting. It resolves approved identities, periods, comparisons, ranking conditions and attribution exclusions, then calls existing calculation functions. It does not infer a borrower's underlying financial condition, explain a rating event without data, forecast, recommend an investment/credit action, or operate transactions.

The implementation contains deterministic semantic interpretation and manual weighted matching. **It is not a learned model, but that fact alone does not establish exclusion from the bank's AI/model/analytics policy.** Obtain a written scope/classification decision based on the actual architecture, code, data, purpose, runtime and development provenance. Do not present “No ML”, mandatory confirmation or `liveReviewAcknowledged` as an exemption.

Suggested factual description:

> This release uses manually maintained CSV dictionaries, typed parsing rules, explicit semantic features and fixed scoring weights to translate English RWA requests into predefined read-only reporting commands. Financial values are calculated by the existing authorised data engine. No learned model or external AI service is used in production. Governance classification, access controls and deployment security require internal review.

## Required approvals / evidence to fill locally

| Review area | Local owner / evidence |
|---|---|
| AI/model/analytics classification of manual semantic scoring | Pending bank review |
| AI-assisted development/tool policy | Pending bank review |
| Data authority, internal IDs, RLS and JSON cell access | Pending live tests |
| Tableau SDK version / internal host / SSO / CSP | Pending live tests |
| Rule authoring, peer review, tests, atomic artifact approval | Compiler and test mechanism included; organisational approval not implemented |
| Unseen user-query corpus and numerical acceptance | Blank holdout template and harness provided; independent corpus not supplied |
| Worst-case latency/memory/DoS | Local synthetic observations only |
| Release rollback and artifact hosting controls | Apply existing bank change process |

The default config locks live mode (`liveReviewAcknowledged:false`). Setting it true must follow the real approval process; the browser cannot authenticate whether approval happened. Keep `requireConfirmation:true`. Run a staged known-data test before any live rollout.

Financial conventions: one consistent USDm basis in the sample; additive non-overlapping driver contributions; no double-counting CG and PD/new business and EAD axes; missing driver data are not zeros; group/entity balance is a stock, not a sum across months; excluded FX is recorded-attribution subtraction, not a true fixed-FX counterfactual. Actual ledger/business lineage must be verified upstream.
