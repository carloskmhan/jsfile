# Architecture and requirements mapping

The implementation keeps the v3.0.1 UI/provider/executor contract and replaces the NLP frontend. `rule_parser.js` is a compatibility export, not a large regex/if chain. Regexes remain inside small domain-specific parsers, rather than a single universal expression.

| Requested stage | Implementation | Output / gate |
|---|---|---|
| 1 Text normalization | `semantic/text.js` | Original text retained, normalized Unicode tokens |
| 2 Dictionary/aliases | `semantic/dictionary.js` | Longest literal phrases, protected identities, collisions |
| 3 Slot extraction | `semantic/slots.js`, `periods.js` | Subject IDs, period, metric, topN, driver, threshold, refs |
| 4 Relations/negation | `semantic/relations.js` | Pair vs exclusions/inclusions, checks, contradictions |
| 5 Explicit features | `semantic/features.js` | Named concepts/coordinates with manual strengths |
| 6 Manual matching | `semantic/scoring.js` | Component points and negative contradictions |
| 7 Top-K | same module | All scores computed; top K (default 3) explained |
| 8 Constraints | `semantic/validation.js` | Required/optional/forbidden, scope and executor limitations |
| 9 Decisions | same + `engine.js` | min score, margin, unknown, ambiguity, unsupported |
| 10 Conversation patch | `semantic/followups.js` | Existing plan + reviewed patch; pending state not committed |
| 11 Command | `semantic/engine.js` | Legacy executor plan plus canonical semantic slots |
| 12 Data/execution | `semantic/routing.js`, existing provider, `rwa_engine.js` | Approved data reloaded; deterministic arithmetic |
| 13 Response | existing `rwa_engine.js`/UI | Templates and tables with calculation evidence |

A **tentative** context projection is needed before scoring/validation to know whether inherited required slots are complete. It does not mutate conversation state. Final state is committed only after preview confirmation and successful execution. This is not a hidden early answer or old-result reuse.

## Scoring

For each command:

```text
positive = sum(manual component weight × explicit match strength)
penalty  = sum(negative contradiction weight × contradiction strength)
fit      = clamp((positive + penalty) / available positive weight, 0, 1)
```

Metric RWA can be an explicit match or marked domain default. Subject/period can be inherited from a valid context. Missing optional modifier components do not artificially lower every score. Primary action must still exist, and contradictions cannot be ignored. Supporting features are optional explicit coordinates. No cosine calculation is needed; the feature representation stays transparent.

A fit value of 0.93 is **not** a 93% probability of correct interpretation. The UI's normal operation does not expose score as an assurance; debug shows points, feature names, sources, penalties, candidate constraints and decision.

## Command/data boundary

The NLP plan carries IDs/names, target period, operation, filters, ranking options and exclusions. It carries no inferred RWA balance, financial driver amount or new economic cause. `planDataRequest` uses authorised catalog identities to determine the group(s)/portfolio data needed, including rank references. RWA values are calculated only from the loaded records.

State projection uses `planOnly`. Successful commit uses `commitState`; it stores only a finite allowlist of plan parameters plus ID/name/rank references, not previous `result` values. The engine may keep its last answer for the UI, but the parser and cross-group fetch do not read its RWA amounts as facts.

Data fetch failures invalidate the ready engine and pending preview. State of the last successful command may remain as parameters, but no old numerical report can execute without newly validated data. Context changes reset/invalidate previews. Preview expiry is two minutes. Confirmation uses immutable request/context plus data-generation and state-snapshot checks; it is not an approval/authentication boundary.

## Relationships and limits

- `Compare Samsung and Toyota` uses a pair, not two independent root reports.
- `Top 10 groups excluding Samsung` means portfolio ranking with an exclusion; Samsung is not the rank subject.
- `Wasn't CG the main driver?` checks the positive proposition and explicitly labels that convention.
- “not July”, unresolved “it”, unsupported OR/forecast/new metric, contradictory metrics or directions, unavailable last-result rank → clarification/rejection.
- Entity aliases resolve within actual parent IDs. Ambiguous alias/name does not fall back to a guessed target.
- Two subjects OR two periods can be compared, not a four-way matrix. Driver-specific comparison and arbitrary product/location filters are not implemented. Supported product/location rankings require the source grain to contain those values.

## Compiler/runtime trust boundary

CSV has a finite schema and no executable cell contents. The compiler's checks are more extensive than the lightweight runtime shape guards. Deploy only compiler-generated artifacts under normal access controls. A privileged attacker who replaces JS/JSON can change tool behavior; hashing alone does not authenticate a deployment. Review the complete rules bundle and source, not merely whether a score passes a threshold.

The generated model-free runtime does not require Python, Node, external libraries, pretrained weights, tokenizer models or WASM. The Tableau SDK is still an external dependency supplied from the approved Tableau environment.

Numeric threshold filtering currently requires a USDm basis. Decline/absolute-magnitude threshold conditions are rejected rather than silently mapped to signed-delta comparisons; request those rankings without thresholds.
