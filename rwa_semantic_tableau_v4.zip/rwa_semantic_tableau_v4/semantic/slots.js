import {asNumber,overlaps,uniq} from './text.js';
import {parsePeriods} from './periods.js';
const DRIVER_MAP=Object.freeze({DRIVER_CG:'CG',DRIVER_EAD:'EAD',DRIVER_PD:'PD',DRIVER_LGD:'LGD',DRIVER_FX:'FX',DRIVER_MATURITY:'Maturity',DRIVER_CRM:'CRM',DRIVER_BASEL:'Basel Method',DRIVER_NEW_BUSINESS:'New Business',DRIVER_NOVATION:'Novation',DRIVER_AMENDMENT:'Amendment',DRIVER_TRANSFER:'Booking Transfer',DRIVER_OTHER:'Other'});
export function extractSlots(text,lex,anchor,settings){
  const dates=parsePeriods(text,anchor,lex.names,settings.max_window_months);
  if(dates.error)return {...dates};
  const drivers=lex.matches.filter(m=>DRIVER_MAP[m.concept]).map(m=>({...m,driver:DRIVER_MAP[m.concept],kind:'driver'}));
  let topN=null,topSpan=null;
  const m=text.match(/\b(?:top|bottom|first|largest|biggest|leading)\s+(\d{1,3}|one|two|three|four|five|six|seven|eight|nine|ten|twenty|fifty)\b/);
  if(m&&!lex.names.some(n=>overlaps(n,{start:m.index,end:m.index+m[0].length}))){
    topN=asNumber(m[1]);const offset=m[0].lastIndexOf(m[1]);topSpan={kind:'n',text:m[1],start:m.index+offset,end:m.index+offset+m[1].length};
    if(topN<1||topN>settings.max_top_n)return{error:'Top N must be between 1 and '+settings.max_top_n+'.',code:'INVALID_SLOT'};
  }
  const thresholds=[];
  for(const t of text.matchAll(/\b(above|below|greater than or equal to|less than or equal to|greater than|less than|more than|under|at least|at most|no more than|no less than|over)\s+(?:\$\s*|usd\s*)?(\d+(?:\.\d+)?)\s*(bn|billion|billions|million|millions|usdm|m|b|thousand|k|percent|%)\b|\b(above|below|over|under|at least|at most)\s+(\d+(?:\.\d+)?)\s*%/g)){
    const span={start:t.index,end:t.index+t[0].length,text:t[0],kind:'threshold'};
    if([...lex.names,...dates.spans].some(b=>overlaps(b,span)))continue;
    const phrase=t[1]||t[4],number=Number(t[2]||t[5]),unit=t[3]||'%';
    const op=({above:'GT',over:'GT','greater than':'GT','more than':'GT',below:'LT',under:'LT','less than':'LT','at least':'GTE','greater than or equal to':'GTE','no less than':'GTE','at most':'LTE','less than or equal to':'LTE','no more than':'LTE'})[phrase];
    const metric=['percent','%'].includes(unit)?'PERCENT':'CHANGE';const factor=/^(bn|b|billion|billions)$/.test(unit)?1000:/^(k|thousand)$/.test(unit)?.001:1;
    thresholds.push({...span,value:number*factor,op,metric,unit});
  }
  if(thresholds.length>1)return{error:'Multiple numeric bounds are not yet supported; use one explicit threshold.',code:'UNSUPPORTED_MODIFIER'};
  if(lex.matches.some(m=>['GT','GTE','LT','LTE'].includes(m.concept)&&!thresholds.some(s=>overlaps(s,m)))&&!/\bover (?:the )?(?:last|past|time)\b/.test(text))return{error:'Specify the threshold with its unit, for example above 25m or above 10%.',code:'INVALID_SLOT'};
  const refs=[];
  const referenceRe=/\b(the first one|first one|the second one|second one|the third one|third one|the largest one|largest one|the next one|next one|that entity|that subsidiary|that group|that one|the first|the second|the third)\b/g;
  for(const r of text.matchAll(referenceRe)){
    const span={start:r.index,end:r.index+r[0].length,text:r[0],kind:'rankref'};
    if(lex.names.some(n=>overlaps(n,span)))continue;
    const index=/second/.test(r[0])?1:/third/.test(r[0])?2:/next/.test(r[0])?'next':/that/.test(r[0])?'focus':0;
    refs.push({...span,index});
  }
  const percentage=!!lex.concepts.PERCENT||thresholds.some(t=>t.metric==='PERCENT')&&/\bby\b/.test(text);
  const metric=lex.concepts.BALANCE?'BALANCE':percentage?'PERCENT':'CHANGE';
  let direction=lex.concepts.ABSOLUTE?'ABSOLUTE':lex.concepts.DECREASE?'DOWN':lex.concepts.INCREASE?'UP':'AUTO';
  if(/\b(bottom|lowest|smallest|minimum|trough)\b/.test(text))direction='DOWN';
  if(percentage&&/\bpercentage (increase|growth)\b/.test(text))direction='UP';
  if(percentage&&/\bpercentage decrease\b/.test(text))direction='DOWN';
  const dimension=lex.concepts.PRODUCT?'PRODUCT':lex.concepts.LOCATION?'LOCATION':lex.concepts.ENTITY?'ENTITY':lex.concepts.GROUP?'GROUP':null;
  return {names:lex.names,drivers,period:dates.period,periodSpans:dates.spans,topN,topSpan,threshold:thresholds[0]||null,
    references:refs,metric,direction,dimension,concise:!!lex.concepts.BRIEF,
    aggregation:dimension,forecast:!!lex.concepts.UNSUPPORTED_FORECAST,metricExplicit:!!(lex.concepts.BALANCE||lex.concepts.PERCENT),
    spans:[...dates.spans,...drivers,...refs,...thresholds,...(topSpan?[topSpan]:[])]};
}
export function publicSlots(plan){
  return {intent:plan.semanticIntent,metric:'RWA',entity:plan.entityId||plan.groupId||null,
    entities:plan.comparisonIds||[],period:plan.period,direction:plan.direction,scope:plan.entity?'ENTITY':plan.group?'GROUP':'PORTFOLIO',
    ranking:['TOP_CLIENTS','TOP_ENTITY'].includes(plan.action),topN:plan.topN,comparison:plan.comparison||null,
    driver:plan.driver,filter:plan.condition,modifier:{excludedDrivers:plan.excludedDrivers,excludedEntities:plan.excludedEntityIds||[],excludedGroups:plan.excludedGroupIds||[]},
    aggregation:plan.dimension,rankingMetric:plan.metric};
}
