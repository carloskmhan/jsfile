import {uniq,overlaps,asNumber} from './text.js';
const MONTHS={jan:1,january:1,feb:2,february:2,mar:3,march:3,apr:4,april:4,may:5,jun:6,june:6,jul:7,july:7,aug:8,august:8,sep:9,sept:9,september:9,oct:10,october:10,nov:11,november:11,dec:12,december:12};
export function shiftMonth(month,n){const [y,m]=month.split('-').map(Number);const d=new Date(Date.UTC(y,m-1+n,1));return `${d.getUTCFullYear()}-${String(d.getUTCMonth()+1).padStart(2,'0')}`;}
export function monthRange(start,end,max=120){
  if(!/^\d{4}-(0[1-9]|1[0-2])$/.test(start)||!/^\d{4}-(0[1-9]|1[0-2])$/.test(end)||start>end)throw new Error('Invalid chronological month range.');
  const out=[];for(let m=start;m<=end;m=shiftMonth(m,1)){out.push(m);if(out.length>max)throw new Error('Period exceeds '+max+' months.');}return out;
}
/** Finite reporting calendar syntax, anchored to selected/report month, not the system clock. */
export function parsePeriods(text,anchor,blocked=[],max=120){
  const spans=[],found=[];const add=(m,month)=>{const s={start:m.index,end:m.index+m[0].length,text:m[0],kind:'period',month};if(!blocked.some(b=>overlaps(b,s))&&!spans.some(b=>overlaps(b,s))){spans.push(s);if(month)found.push(s);}};
  if(!/^\d{4}-(0[1-9]|1[0-2])$/.test(anchor))return{error:'No valid report month is available; select a month.',code:'MISSING_PERIOD',spans};
  for(const m of text.matchAll(/\b(20\d{2})[-/](\d{1,2})(?![\d-])/g)){
    if(+m[2]<1||+m[2]>12)return{error:'Invalid month '+m[0]+'.',code:'INVALID_PERIOD',spans};add(m,`${m[1]}-${m[2].padStart(2,'0')}`);
  }
  const yearMatch=[...text.matchAll(/\b(20\d{2})\b/g)].find(m=>!blocked.some(s=>overlaps(s,{start:m.index,end:m.index+m[0].length})));
  const defaultYear=yearMatch?.[1]||anchor.slice(0,4);
  const named=/\b(january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sept?|oct|nov|dec)(?:\s*[-/ ]\s*(20\d{2}|\d{2})(?!\d))?\b/g;
  for(const m of text.matchAll(named)){
    if(m.index===0&&/^may (i|we)\b/.test(text))continue;
    const year=m[2]?(m[2].length===2?String(2000+Number(m[2])):m[2]):defaultYear;
    add(m,`${year}-${String(MONTHS[m[1]]).padStart(2,'0')}`);
  }
  found.sort((a,b)=>a.start-b.start);const months=uniq(found.map(x=>x.month));
  if(months.length>2)return{error:'At most two explicit months are supported; use a month range for a longer window.',code:'UNSUPPORTED_PERIOD',spans};
  if(months.length===2){
    const range=/\b(from|through|until)\b/.test(text)||/\bto\b/.test(text)&&!/\b(compare|compared|versus|vs|difference)\b/.test(text);
    if(!range&&!/\b(compare|compared|versus|vs|difference|different|than|between)\b/.test(text))return{error:'Two months were named without a comparison or range relation. Say compare June with July, or from June to July.',code:'AMBIGUOUS_PERIOD',spans};
    const period=range?{mode:'window',start:months[0],end:months[1]}:{mode:'comparison',months};
    try{if(range)monthRange(period.start,period.end,max);}catch(e){return{error:e.message,code:'INVALID_PERIOD',spans};}
    return{period,spans};
  }
  let m=text.match(/\b(?:last|past|recent)\s+(\d{1,3}|one|two|three|four|five|six|seven|eight|nine|ten|twelve|twenty)\s+months?\b/);
  if(m){const n=asNumber(m[1]);if(n<1||n>max)return{error:'Choose 1–'+max+' months.',code:'INVALID_PERIOD',spans};add(m,null);const end=months[0]||anchor;return{period:{mode:'window',start:shiftMonth(end,1-n),end},spans};}
  m=text.match(/\b(3m|6m|12m)\b/);if(m){add(m,null);const end=months[0]||anchor;return{period:{mode:'window',start:shiftMonth(end,1-parseInt(m[1])),end},spans};}
  m=text.match(/\bq([1-4])(?:\s+(20\d{2}))?\b/);if(m){add(m,null);const year=m[2]||defaultYear;return{period:{mode:'window',start:`${year}-${String(+m[1]*3-2).padStart(2,'0')}`,end:`${year}-${String(+m[1]*3).padStart(2,'0')}`},spans};}
  m=text.match(/\b(ytd|year to date)\b/);if(m){add(m,null);const end=months[0]||anchor;return{period:{mode:'window',start:end.slice(0,4)+'-01',end},spans};}
  m=text.match(/\b(last|previous|prior) quarter\b/);if(m){add(m,null);const current=`${anchor.slice(0,4)}-${String(Math.floor((+anchor.slice(5)-1)/3)*3+1).padStart(2,'0')}`;return{period:{mode:'window',start:shiftMonth(current,-3),end:shiftMonth(current,-1)},spans};}
  m=text.match(/\b(last|previous|prior) month\b/);if(m){add(m,null);const base=months[0]||anchor,prior=shiftMonth(base,-1);return{period:/\b(compare|compared|versus|vs|difference|than)\b/.test(text)?{mode:'comparison',months:[base,prior]}:{mode:'month',month:prior},spans};}
  if(months.length){if(/\bsince\b/.test(text))return{period:{mode:'window',start:months[0],end:anchor},spans};return{period:{mode:'month',month:months[0]},spans};}
  m=text.match(/\b(latest|current|this) month\b/);if(m){add(m,null);return{period:{mode:'month',month:anchor},spans};}
  return {period:null,spans};
}
