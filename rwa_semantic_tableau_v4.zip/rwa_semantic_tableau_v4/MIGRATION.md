# v3.0.1 → v4 migration

## Do not overwrite the live folder blindly

1. Preserve the original v3.0.1 ZIP, `tableau_config.txt`, approved catalog and site controls as a rollback.
2. Create a separate v4 staging folder. This upgrade needs the new JS files and complete `semantic/` directory, **not just command_patterns.txt**.
3. Merge the bank's Tableau URL, approved API URL, worksheet/filter/field mappings, limits, approved origins and data source paths into v4's config. Keep `requireConfirmation:true`. Keep `liveReviewAcknowledged:false` until the actual review is complete.
4. Replace sample IDs/catalog entries with approved IDs and update `rules/aliases.csv` to the same IDs/parents. Do not place synthetic sample data in a live financial source.
5. Compile CSVs and run tests. Alias changes may invalidate sample-based tests; use a separate approved fixture/corpus for real identities rather than changing numerical golds to force a pass.
6. Stage the runtime assets together and verify HTTP modules/fetch, CSP, SSO, Tableau API, RLS, truncation, cross-group refresh and failures.
7. Only after approval, set `mode:tableau` and the review acknowledgement flag. That flag is configuration, not evidence of approval or access enforcement.

## Preserved interfaces

Data columns and Tableau v2 classic script loading are unchanged. `tableau_adapter.js`, `csv_adapter.js`, `group_catalog.js`, `network.js`, `styles.css` and source sample files match the baseline hashes. Chat history and preview/confirm/cancel remain. Arithmetic functions and templates are reused; group exclusions, candidate sets and state commits extend the executor.

## New management

`commands_editor.html` is read-only guidance. `commands_editor.js` and old `command_fields.js` are no longer runtime dependencies. The rule file is comment-header + JSON schema 4, not old template JSON. Mixing v3 and v4 will explicitly fail; do not strip the header to trick the old parser.

Once v4 is staged, everyday vocabulary/alias/weight/follow-up changes require only CSV editing, compiler success, tests, approval and TXT replacement. New operations still require source changes. Rebuild the standalone demo separately with `python tools/build_standalone.py`; it embeds the rules and does not read a changed external TXT.

## Deliberate behavior changes, not concealed regressions

Raw legacy tests are preserved and rerun. Six old expectations differ:

- One rhetorical-negation assertion expected the answer to begin `Yes`. The new answer first says “Checking the positive proposition about CG: …”, then the same checked result. Financial calculation is unchanged.
- Four follow-up cases asked offsets/reconciliation after a two-month comparison. The old suite expected silent reversion to the screen month; v4 asks for one month instead. Use `What are the offsets in May?`.
- One request for the next entity after the final ranked entity expected the last entity again. v4 reports that no next reference exists.

`tests/run_all.mjs` checks that these exact six, and no new unexplained failures, occur in the preserved legacy expectations. It does not change their raw failure reports. `reports/migration_tests.json` documents the accepted behavioral differences.

A previously chosen group/window is not always inherited into a completely new sentence. Explicit follow-up patterns use the last successful plan; full questions use explicit values/current UI defaults. Cross-group entity exclusions and incompatible ID sets are cleared. By default FX attribution exclusions remain for an explicit “same/how about” group switch; inspect the preview to confirm the basis.

## Deployment files

The web-only ZIP contains the HTML/CSS/JS/semantic modules, generated TXT, config and sample catalog/data. Do not publish `tests/`, detailed query logs, `reports/`, developer tools or the original MiniLM assets on the production site. The full source ZIP contains these for review/development. Protect catalog names and artifacts under the bank's normal access/change controls.
