# RWA Reports — CSV Semantic Rules v4

**4.0.0-review · deterministic, manually authored rules · production-like review build**

기존 v3.0.1의 채팅 UI, 실행 전 확인, chat history, Tableau v2/CSV data adapter와 RWA 계산/보고 코드를 유지하고 질문 해석 계층을 교체했습니다. 모델 학습, learned embedding, MiniLM, LLM, ONNX, Transformers.js, 외부 AI API는 운영 경로에 없습니다. 선택적 A/B 개발 도구만 사용자가 보존한 원본 MiniLM 패키지를 로컬에서 실행합니다.

**Non-ML은 Non-AI 또는 사내 승인 완료를 뜻하지 않습니다.** 이번 버전은 명시적 의미 특징과 수동 점수를 사용하는 설계 변경입니다. 이전 고정 명령 도구에 대한 분류를 그대로 승계하지 말고, 실제 코드/용도와 CSV 변경 절차를 함께 재검토하십시오. 일반 자연어를 모두 이해하거나 MiniLM과 99% 동등하다는 주장은 하지 않습니다.

## 1. 가장 빠른 확인

- `standalone_demo.html`: 합성 데이터가 내장된 단일 HTML. 모델이나 서버가 필요하지 않습니다. JavaScript를 실행하는 브라우저에서 여십시오. 파일 미리보기 앱은 JS를 실행하지 않을 수 있습니다.
- `demo.html`: 실제 웹 앱. 승인된 정적 HTTP(S) 호스트에서 다른 JS 파일과 함께 제공합니다. ES module과 fetch를 쓰므로 file:// 직접 열기용이 아닙니다.
- 로컬 개발 서버: `node serve.mjs` → `http://127.0.0.1:8000/demo.html`.
- 기본값은 `mode: sample`, `requireConfirmation: true`, `liveReviewAcknowledged: false`입니다. 기본 상태는 실서버 데이터에 연결하지 않습니다.

실행 예:

```text
Why did Samsung's RWA increase in July?
How about Toyota?
And August?
```

각 요청은 먼저 그룹/계열사/기간/제외 조건을 보여줍니다. `Run report` 후에만 성공한 요청의 의미 상태를 저장합니다. **샘플의 Samsung/Toyota 7월은 실제로 감소이므로 감소로 답합니다.** 원본 샘플에는 Toyota 8월이 없으므로 세 번째 요청은 8월로 정상 해석한 뒤 데이터 없음으로 중단합니다. 회귀 테스트에만 별도로 명시한 합성 8월 데이터를 사용합니다. 실제 서비스는 승인된 Tableau 데이터에 따라 답합니다.

## 2. 평소 유지보수: CSV만 수정

```text
rules/*.csv 수정
  → python build_command_patterns.py
  → command_patterns.txt 원자적 생성
  → 검토/회귀 테스트
  → 생성 파일 승인 배포, 브라우저 새로고침
```

```bash
python build_command_patterns.py
python build_command_patterns.py --check
node tests/run_all.mjs
```

컴파일러는 Python 3.10+ 표준 라이브러리만 사용하며 pip 설치가 필요 없습니다. Windows에서도 `python` 명령을 사용합니다. Node는 개발 테스트/로컬 서버용이며, 운영 서버의 Python/Node 프로세스는 필요하지 않습니다. 실제 테스트 환경은 `BUILD_INFO.json`에 기록합니다.

| 소스 | 관리 내용 |
|---|---|
| `rules/commands.csv` | 의도, 기존 실행 함수, 필수/선택/금지 슬롯, 특징·가중치·최소 점수·margin |
| `rules/synonyms.csv` | 단어/구문 → canonical concept, 수동 신뢰 강도 |
| `rules/aliases.csv` | 실제 그룹/계열사 ID, parent ID, 이름/별칭 |
| `rules/followups.csv` | 후속질문 패턴 → 허용된 context patch |
| `rules/settings.csv` | 상위 후보 수, 입력/기간 제한, slot inheritance 정책 |

`commands_editor.html`은 이제 안내 페이지입니다. HTML 편집기는 runtime artifact를 수정하지 않습니다. `command_patterns.txt`를 직접 편집하지 마십시오. v3 TXT와 v4 runtime은 호환되지 않아 혼용하면 명시적으로 오류가 납니다. v4로 처음 올릴 때는 새 모듈도 함께 배포해야 합니다. 그 이후 표현·가중치 변경은 CSV→컴파일→TXT 교체로 가능합니다.

### 새 표현 추가 예

`synonyms.csv`에 아직 없는 구문을 한 행으로 추가합니다.

```csv
concept,phrase,weight,enabled,notes
ROOT,please explain the reasons,1,true,Approved movement explanation phrase
```

여기서 `ROOT`는 root-cause attribution report를 요청하는 명시적 개념입니다. 완성된 문장을 외우지 않고, 긴 구문/그룹/기간/조건을 각기 해석합니다. 기존에 같은 구문이 있으면 새 행을 중복 추가하지 말고 기존 행을 수정합니다. 새로운 계산·새 개념의 정의·새 slot type은 여전히 소스 변경과 검토가 필요합니다. 상세 schema와 예시는 `COMMANDS.md`에 있습니다.

## 3. 무엇을 보존했나

`styles.css`, `tableau_adapter.js`, `csv_adapter.js`, `group_catalog.js`, `network.js`, 원본 샘플 CSV/카탈로그는 v3.0.1과 바이트 단위 동일합니다. `reports/source_diff.json`에 원본과의 해시 비교를 제공합니다. UI 레이아웃, Enter 전송, 확인/취소, history, Tableau classic script 로딩을 유지했습니다. `rwa_engine.js`는 기존 산술/템플릿을 유지하면서 그룹 제외·ID 기반 최근 순위 집합·상태 저장을 확장했습니다. 문장 해석은 `semantic/` 모듈로 분리했습니다.

## 4. 해석·상태 정책

- 단어/다중 단어 사전, 긴 표현 우선, 실제 ID에 연결되는 alias를 사용합니다.
- 선택 지표, 기간, 비교 관계, 제외 대상, threshold, Top N을 분리합니다.
- 설명 가능한 features와 수동 weighted score를 사용합니다. `ruleConfidence`는 **정답 확률이 아닌 적합도 점수**입니다.
- 최소 score, top1/top2 margin, contradiction, 필수/금지 슬롯, 미해석 단어를 검사합니다. 점수가 높아도 검증 실패 시 실행하지 않습니다.
- `How about Toyota?`는 이전 실행된 요청에서 대상만 교체합니다. `And August?`는 기간만 교체합니다.
- 대상이 바뀌면 Tableau/CSV provider로 대상 데이터를 다시 읽고 계산합니다. 이전 RWA/driver 숫자는 새 결과로 복사하지 않습니다.
- `Top 10 groups` → `Only those above 25m` → `Compare the first one with Toyota`를 지원합니다. 이전 결과에서는 ID/이름/순위만 참조하며 금액은 다시 계산합니다.
- 확인 취소, 잘못된 질문, 데이터 오류는 성공한 상태를 갱신하지 않습니다. 오래된 preview token/다른 data generation은 실행되지 않습니다.
- 완전한 새 질문은 현재 명시값/화면 context를 사용합니다. 이전 조건을 무조건 끌고 가지 않습니다.

## 5. 실데이터 연결

`MIGRATION.md`에 따라 별도 새 폴더에 배포한 뒤, 기존 사내 URL/워크시트/필드/권한 설정을 보존하여 옮기십시오. 네 컬럼 계약은 그대로입니다.

```text
client_group_id | client_group_name | group_location | json_data
```

`rwa_sample_data.txt`는 이름/ID 카탈로그입니다. 금융 실적의 원천이 아닙니다. `aliases.csv`는 해당 승인된 ID에 연결해야 하며, alias가 존재한다고 데이터 권한이나 실제 데이터가 생기지 않습니다. 전체 그룹 조회는 live에서 기본 비활성화입니다.

## 6. 테스트·설명·A/B

```bash
node tools/explain.mjs "What drove Samsung RWA higher in July?"
node tools/evaluate.mjs tests/questions.csv reports/my_run.json
python tests/browser_test.py --mode dom
python tests/browser_test.py --mode http
```

626개의 개발자 작성 회귀 질문은 intent/entity/period/slot/후속/unsupported/ambiguity 지표를 따로 계산합니다. 500~1000개 이상으로 늘리려면 동일 CSV schema의 행을 추가하면 됩니다. `tests/holdout_template.csv`는 **빈 양식**이며 독립 테스트 데이터가 아닙니다.

```bash
python tools/ab_minilm.py --baseline-dir /path/to/rwa_tableau_v2 \
  --corpus tests/my_holdout.csv --require-holdout --out reports/my_ab.json
```

A/B는 선택적 개발 환경에서만 실행합니다. Playwright/Chromium과 **기존 원본 MiniLM 파일**이 필요합니다. 자동 모델 다운로드를 하지 않습니다. 상세 비교 정의와 측정 한계는 `BENCHMARK.md`를 읽으십시오. 사내 질문은 승인된 개발 환경에서만 테스트하십시오.

## 7. 배포 전 한계

실제 은행 Tableau/SSO/SharePoint, HTTP ESM/fetch 로딩, 서버 CSP, 권한/RLS, 침투 테스트와 독립 사용자 검증은 완료되지 않았습니다. 이 환경에서는 로컬 URL 탐색이 관리 정책으로 차단되어 브라우저 UI는 동일 번들 HTML을 메모리 문서에 로드해 확인했습니다. 정책을 우회하지 않았습니다. UI 테스트 통과를 실서버 연결/보안 인증으로 사용하지 마십시오.

지원 범위는 영어 RWA historical reporting입니다. 새로운 금융 원인 추론, 전망, 투자/여신 판단, arbitrary SQL/JS, 두 그룹과 두 기간의 동시 교차 비교, driver-specific comparison, 자유로운 복합 논리, 임의 신조어는 지원하지 않거나 명확화를 요청합니다. 데이터 불충분/동명이인/이름 충돌은 임의 추정하지 않습니다.

`ACCEPTANCE.md`, `CISO_SECURITY.md`, `DEPLOYMENT_REVIEW.md`를 검토하십시오.

Numeric threshold filtering currently requires a USDm basis. Decline/absolute-magnitude threshold conditions are rejected rather than silently mapped to signed-delta comparisons; request those rankings without thresholds.
