"""Package the current tested source and a web-only set, without any MiniLM model assets."""
from pathlib import Path
import hashlib,json,zipfile,platform,subprocess
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT.parent/'work/baseline/rwa_command_tableau_v3_0_1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(name):return json.loads((ROOT/'reports'/name).read_text())
def run():
 sem=load('semantic_regression.json');core=load('engine_tests.json');comp=load('compiler_tests.json');browser=load('browser_dom_tests.json');mig=load('migration_tests.json');ab=load('ab_results.json')
 if sem['failed'] or core['failed'] or comp['failed'] or browser['failed'] or not mig['allDifferencesExplicitlyExplained']:raise ValueError('Current test reports do not meet documented local release gates.')
 if any(sha(ROOT/k)!=v for k,v in ab['newRuntimeHashes'].items()):raise ValueError('Measured A/B source hash does not match this runtime. Rerun or explicitly remove the comparison claim.')
 diff=[]
 if BASE.exists():
  for p in sorted(ROOT.glob('*')):
   if p.is_file() and (BASE/p.name).exists():diff.append({'file':p.name,'originalSha256':sha(BASE/p.name),'currentSha256':sha(p),'unchanged':sha(p)==sha(BASE/p.name)})
 (ROOT/'reports/source_diff.json').write_text(json.dumps({'baseline':'rwa_command_tableau_v3_0_1','files':diff},indent=2))
 registry=json.loads('\n'.join(x for x in (ROOT/'command_patterns.txt').read_text().splitlines() if not x.startswith('#')))
 summary={'release':'4.0.0-review','status':'Production-like review build; bank deployment and governance not approved',
  'compiler':{'passed':comp['passed'],'failed':comp['failed']},'engineControls':{'passed':core['passed'],'failed':core['failed']},
  'corpus':{k:sem[k] for k in ['total','passed','failed','metrics']},
  'legacy':{'originalAccountingExpectations':mig['legacyAccounting'],'originalDialogueExpectations':mig['legacyDialogues'],'sixExplicitChanges':mig['allDifferencesExplicitlyExplained']},
  'browser':{'mode':'in-memory bundled HTML only','passed':browser['passed'],'failed':browser['failed'],'httpNavigation':'Blocked by administrator; not certified'},
  'minilmAB':{'executed':True,'corpus':'same developer-authored regression, not independent','tokenFixtureMatches':ab['baselineParity']['tokenMatches'],'tokenFixtureTotal':ab['baselineParity']['fixtureCount'],'maximumEmbeddingDifference':ab['baselineParity']['maxEmbeddingDifference'],'fullResults':'reports/ab_results.json'},
  'counts':{k:len(registry[k]) for k in ['commands','synonyms','aliases','followups']},
  'limitations':['No blind/independent corpus provided','No live bank Tableau/SSO/SharePoint/HTTP module+CSP validation','No AI-governance exemption','No total-process/WASM memory or bank network load measurement']}
 (ROOT/'reports/release_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
 runtime=[p for p in ROOT.glob('*.js')]+list((ROOT/'semantic').glob('*.js'))+[ROOT/x for x in ['demo.html','styles.css','bootstrap.js','command_patterns.txt','tableau_config.txt','rules_config.txt','rwa_sample_data.txt','tableau_sample.csv','commands_editor.html']]
 runtime=sorted(set(runtime));js=sum(p.stat().st_size for p in runtime if p.suffix=='.js')
 info={'release':'4.0.0-review','python':platform.python_version(),'node':subprocess.check_output(['node','--version'],text=True).strip(),'browser':ab['browser'],
  'runtimeJsBytesExcludingTableauSDK':js,'generatedRuleBytes':(ROOT/'command_patterns.txt').stat().st_size,'ruleSources':registry['sourceSha256'],'learnedRuntimeAssets':[],
  'runtimeFiles':[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in runtime],
  'baselineZip':{'path':'rwa_command_tableau_v3_0_1.zip','sha256':sha(ROOT.parent/'rwa_command_tableau_v3_0_1.zip')},
  'originalMiniLMPreservedSeparately':ab['baselineHashes'],'reviewNotes':'Same input/data/context/rules produce the same command; timestamps/latency/preview tokens are diagnostic, not semantic parameters.'}
 (ROOT/'BUILD_INFO.json').write_text(json.dumps(info,indent=2))
 # Do not include caches or historical duplicate development logs in the distributable.
 files=[p for p in sorted(ROOT.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ['.pyc','.log'] and p.name not in ['ab_smoke.json','probe.mjs','SHA256SUMS.txt']]
 if any(p.suffix in ['.onnx','.wasm','.bin','.safetensors','.pt'] for p in files):raise ValueError('Unexpected learned/runtime binary in new source package.')
 (ROOT/'SHA256SUMS.txt').write_text('\n'.join(sha(p)+'  '+str(p.relative_to(ROOT)) for p in files)+'\n')
 source=ROOT.parent/'rwa_semantic_tableau_v4.zip';web=ROOT.parent/'rwa_semantic_tableau_v4_web.zip'
 with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in files+[ROOT/'SHA256SUMS.txt']:z.write(p,'rwa_semantic_tableau_v4/'+str(p.relative_to(ROOT)))
 docs=[ROOT/x for x in ['README.md','COMMANDS.md','MIGRATION.md','ARCHITECTURE.md','CISO_SECURITY.md','DEPLOYMENT_REVIEW.md','ACCEPTANCE.md','BUILD_INFO.json']]
 webfiles=sorted(set(runtime+docs));prefix='rwa_semantic_tableau_v4_web/'
 with zipfile.ZipFile(web,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in webfiles:z.write(p,prefix+str(p.relative_to(ROOT)))
  z.writestr(prefix+'SHA256SUMS.txt','\n'.join(sha(p)+'  '+str(p.relative_to(ROOT)) for p in webfiles)+'\n')
  z.writestr(prefix+'WEB_ONLY.txt','This is the deployment subset. CSV sources, compiler, tests, standalone demo and optional A/B tools are in rwa_semantic_tableau_v4.zip. Do not deploy the development tools or MiniLM baseline. Preserve the existing bank config/catalog and review before live use.\n')
 # Verify packaged bytes rather than merely trusting successful zip creation.
 for zp in [source,web]:
  with zipfile.ZipFile(zp) as z:
   if z.testzip():raise ValueError('Archive integrity check failed')
  print(zp, zp.stat().st_size,sha(zp))
 print('Runtime JS bytes',js,'Generated rules',info['generatedRuleBytes'])
if __name__=='__main__':run()
