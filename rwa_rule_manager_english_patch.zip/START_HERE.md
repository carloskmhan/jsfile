# Getting started — RWA Rule Workbench

**English interface update: 1.0.1-en-review**

## Apply this update to an existing installation

1. Export any unsaved browser drafts you need to keep. Close the manager tab, then press **Ctrl+C** in the terminal to stop the Python server.
2. Extract the English patch into the existing project folder containing `rule_manager.py`. Keep the relative folder structure and replace the matching files only.
3. Start the server again with `python rule_manager.py` (or `python3 rule_manager.py` on macOS/Linux).
4. Open `http://127.0.0.1:8765/` and refresh the page. The navigation, forms, status messages and question-test guidance are now in English.

The patch changes presentation text and documentation. It does **not** replace your `rules/*.csv`, `command_patterns.txt`, compiler, RWA engine, Tableau settings or saved backups. User-authored data and existing notes are preserved as entered; they are not automatically translated. There is no need to recompile the rules for this language update.

## Normal use

Python 3.10 or later is required. In the full project folder, run:

```bash
python rule_manager.py
```

**Edit expressions, aliases or follow-ups → Validate & build draft → Test questions → Save CSVs & rebuild**

The browser opens automatically. If it does not, open `http://127.0.0.1:8765/` manually.

CSV files remain the source of truth, and the existing compiler is unchanged. The manager does not connect to live Tableau or automatically update the bank website.

Manual: `LOCAL_RULE_MANAGER.md`

The main RWA application remains `demo.html`. The manager serves its own interface at `/`; it is not a general static server for publishing the main application. Use the original application hosting instructions for `demo.html`.

The single-file `standalone_demo.html` contains embedded sample rules. Saving through the manager does not automatically update that file.
