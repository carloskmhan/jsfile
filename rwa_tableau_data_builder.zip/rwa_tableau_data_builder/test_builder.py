"""Developer-authored synthetic tests. No bank/server/authorization certification."""
import copy
import csv
import json
from pathlib import Path
import tempfile
import time
import unittest
from decimal import Decimal
from build_tableau_csv import build, DataError, parse_month, decimal_value

ROOT = Path(__file__).resolve().parent
BASE_CONFIG = json.loads((ROOT / 'data_mapping.json').read_text())
with (ROOT / 'raw_sample_SYNTHETIC.csv').open(encoding='utf-8-sig', newline='') as f:
    BASE_ROWS = list(csv.DictReader(f))

class BuilderTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.p = Path(self.temp.name)
    def tearDown(self):
        self.temp.cleanup()
    def run_build(self, rows=None, cfg=None, unit='base', currency='USD'):
        rows = copy.deepcopy(BASE_ROWS if rows is None else rows)
        cfg = copy.deepcopy(BASE_CONFIG if cfg is None else cfg)
        fields = list(rows[0])
        with (self.p/'raw.csv').open('w', encoding='utf-8-sig', newline='') as f:
            w=csv.DictWriter(f, fieldnames=fields); w.writeheader(); w.writerows(rows)
        (self.p/'cfg.json').write_text(json.dumps(cfg), encoding='utf-8')
        result = build(self.p/'raw.csv', self.p/'cfg.json', self.p/'output', unit, currency)
        with (self.p/'output'/'tableau_data.csv').open(encoding='utf-8-sig',newline='') as f:
            out=list(csv.DictReader(f))
        return result,out
    def test_repeated_balances_preserved_once(self):
        r,out=self.run_build(); rows=json.loads(out[0]['json_data'])['rows']
        self.assertEqual(r['input_rows'],6); self.assertEqual(len(rows),2)
        self.assertEqual(sum(x['rwa_prev'] for x in rows),1300)
        self.assertEqual(sum(x['rwa_curr'] for x in rows),1570)
        self.assertEqual(sum(sum(x['drivers'].values()) for x in rows),270)
    def test_ids_keep_leading_zeros(self):
        _,out=self.run_build(); self.assertEqual(out[0]['client_group_id'],'000001')
        self.assertEqual(json.loads(out[0]['json_data'])['rows'][0]['entity_id'],'00001001')
    def test_arbitrary_dynamic_driver_retained(self):
        rr=copy.deepcopy(BASE_ROWS);rr[0]['detail_driver']='New 2026 methodology component (test)'
        _,out=self.run_build(rr);self.assertIn(rr[0]['detail_driver'],json.loads(out[0]['json_data'])['rows'][0]['drivers'])
    def test_attributes_retained_in_json(self):
        _,out=self.run_build();a=json.loads(out[0]['json_data'])['rows'][0]['attributes']
        self.assertEqual(a['ead_prev'],1400);self.assertEqual(a['ead_curr'],1500)
        self.assertEqual(a['prev_cg'],'7');self.assertEqual(a['cg'],'8');self.assertEqual(a['scorecard_curr'],'CORPORATE')
    def test_missing_location_sentinel(self):
        r,out=self.run_build();self.assertEqual(out[0]['group_location'],'NOT_PROVIDED');self.assertTrue(r['warnings'])
    def test_unit_mandatory(self):
        with self.assertRaises(DataError):self.run_build(unit=None)
    def test_currency_mandatory(self):
        with self.assertRaises(DataError):self.run_build(currency=None)
    def test_usdm_not_rescaled(self):
        rr=copy.deepcopy(BASE_ROWS)
        for row in rr:
            for k in ['prev_rwa','RWA','RWA Diff by driver','EAD','prev_ead']:row[k]=str(Decimal(row[k])/1000000)
        _,out=self.run_build(rr,unit='million');self.assertEqual(json.loads(out[0]['json_data'])['rows'][0]['rwa_curr'],1250)
    def test_inconsistent_snapshot_fails(self):
        rr=copy.deepcopy(BASE_ROWS);rr[1]['RWA']='1250000001'
        with self.assertRaises(DataError):self.run_build(rr)
        self.assertFalse((self.p/'output').exists())
    def test_inconsistent_attribute_fails(self):
        rr=copy.deepcopy(BASE_ROWS);rr[1]['Scorecard']='DIFFERENT'
        with self.assertRaises(DataError):self.run_build(rr)
    def test_duplicate_driver_default_fails(self):
        rr=copy.deepcopy(BASE_ROWS);rr.append(copy.deepcopy(rr[0]))
        with self.assertRaises(DataError):self.run_build(rr)
    def test_distinct_components_explicitly_sum(self):
        rr=copy.deepcopy(BASE_ROWS)
        for i,row in enumerate(rr):row['component']='C'+str(i)
        rr[0]['RWA Diff by driver']='100000000';extra=copy.deepcopy(rr[0]);extra['component']='C999';rr.append(extra)
        cfg=copy.deepcopy(BASE_CONFIG);cfg['duplicate_driver_policy']='sum_distinct_components';cfg['columns']['component_id']='component'
        _,out=self.run_build(rr,cfg);self.assertEqual(json.loads(out[0]['json_data'])['rows'][0]['drivers']['EAD Increase (STD)'],200)
    def test_duplicate_component_fails(self):
        rr=copy.deepcopy(BASE_ROWS)
        for i,row in enumerate(rr):row['component']='C'+str(i)
        rr.append(copy.deepcopy(rr[0]))
        cfg=copy.deepcopy(BASE_CONFIG);cfg['duplicate_driver_policy']='sum_distinct_components';cfg['columns']['component_id']='component'
        with self.assertRaises(DataError):self.run_build(rr,cfg)
    def test_residual_rejected_default(self):
        rr=copy.deepcopy(BASE_ROWS);rr[0]['RWA Diff by driver']='100000000'
        with self.assertRaises(DataError):self.run_build(rr)
    def test_residual_warn_explicit_does_not_invent_driver(self):
        rr=copy.deepcopy(BASE_ROWS);rr[0]['RWA Diff by driver']='100000000'
        cfg=copy.deepcopy(BASE_CONFIG);cfg['reconciliation_mode']='warn'
        r,out=self.run_build(rr,cfg);self.assertEqual(r['reconciliation_failures'],1)
        d=json.loads(out[0]['json_data'])['rows'][0]['drivers'];self.assertEqual(len(d),3);self.assertNotIn('Other',d)
    def test_negative_balance_rejected(self):
        rr=copy.deepcopy(BASE_ROWS);rr[0]['RWA']='-1'
        with self.assertRaises(DataError):self.run_build(rr)
    def test_nan_rejected(self):
        rr=copy.deepcopy(BASE_ROWS);rr[0]['RWA Diff by driver']='NaN'
        with self.assertRaises(DataError):self.run_build(rr)
    def test_infinite_number_rejected(self):
        with self.assertRaises(DataError):decimal_value('Infinity','x')
    def test_missing_amount_not_zero(self):
        rr=copy.deepcopy(BASE_ROWS);rr[0]['RWA Diff by driver']=''
        with self.assertRaises(DataError):self.run_build(rr)
    def test_missing_driver_not_other(self):
        rr=copy.deepcopy(BASE_ROWS);rr[0]['detail_driver']=''
        with self.assertRaises(DataError):self.run_build(rr)
    def test_unsafe_driver_key_rejected(self):
        rr=copy.deepcopy(BASE_ROWS);rr[0]['detail_driver']='__proto__'
        with self.assertRaises(DataError):self.run_build(rr)
    def test_bad_number_grouping(self):
        with self.assertRaises(DataError):decimal_value('1,00','x')
    def test_comma_and_accounting_negative(self):
        self.assertEqual(decimal_value('(1,000.25)','x'),Decimal('-1000.25'))
    def test_month_forms(self):
        for value in ['2026-07','2026-07-31','Jul-26','July 2026','Jul2026','202607']:
            self.assertEqual(parse_month(value,[]),'2026-07')
    def test_invalid_calendar_date(self):
        with self.assertRaises(DataError):parse_month('2026-02-31',[])
    def test_numeric_date_not_guessed(self):
        with self.assertRaises(DataError):parse_month('07/08/2026',[])
    def test_explicit_date_format(self):
        self.assertEqual(parse_month('07/08/2026',['%d/%m/%Y']),'2026-08')
    def test_conflicting_date_formats(self):
        with self.assertRaises(DataError):parse_month('07/08/2026',['%d/%m/%Y','%m/%d/%Y'])
    def test_missing_year_not_guessed(self):
        with self.assertRaises(DataError):parse_month('July',[])
    def test_unknown_grain_rejected(self):
        cfg=copy.deepcopy(BASE_CONFIG);cfg['balance_grain']='just_sum'
        with self.assertRaises(DataError):self.run_build(cfg=cfg)
    def test_driver_case_collision(self):
        rr=copy.deepcopy(BASE_ROWS);rr[3]['detail_driver']='ead increase (std)'
        with self.assertRaises(DataError):self.run_build(rr)
    def test_existing_output_never_overwritten(self):
        self.run_build();p=self.p/'output'/'tableau_data.csv';before=p.read_bytes()
        with self.assertRaises(DataError):build(self.p/'raw.csv',self.p/'cfg.json',self.p/'output','base','USD')
        self.assertEqual(before,p.read_bytes())
    def test_group_size_limit_before_publish(self):
        cfg=copy.deepcopy(BASE_CONFIG);cfg['max_group_json_bytes']=10
        with self.assertRaises(DataError):self.run_build(cfg=cfg)
        self.assertFalse((self.p/'output').exists())
    def test_missing_driver_is_not_filled_with_zero(self):
        _,out=self.run_build();rr=json.loads(out[0]['json_data'])['rows'];self.assertNotIn('Maturity Increase',rr[1]['drivers'])
    def test_duplicate_name_with_different_ids_rejected(self):
        rr=copy.deepcopy(BASE_ROWS);rr[3]['client name']='Samsung Electronics'
        with self.assertRaises(DataError):self.run_build(rr)
    def test_client_rename_across_months_rejected(self):
        rr=copy.deepcopy(BASE_ROWS);r=copy.deepcopy(rr[3]);r['Reporting Month']='2026-08';r['client name']='Renamed';rr.append(r)
        with self.assertRaises(DataError):self.run_build(rr)
    def test_source_not_changed(self):
        self.run_build();a=(self.p/'raw.csv').read_bytes();self.assertIn(b'000001',a)
    def test_more_than_50k_raw_rows(self):
        rr=[]
        for g in range(1001):
            for e in range(10):
                for d in range(5):
                    r=copy.deepcopy(BASE_ROWS[0]);r.update({'client group name':f'SYNTHETIC GROUP {g:04d}', 'client group id':f'G{g:04d}', 'client name':f'ENTITY {e:04d}', 'LEID':f'E{e:04d}', 'RWA':'105000000','prev_rwa':'100000000','detail_driver':f'Approved synthetic driver {d}','RWA Diff by driver':'1000000'})
                    rr.append(r)
        started=time.perf_counter();r,out=self.run_build(rr)
        self.assertEqual(r['input_rows'],50050);self.assertEqual(r['entity_month_count'],10010);self.assertEqual(len(out),1001)
        (ROOT/'synthetic_scale_result.json').write_text(json.dumps({'input_rows':50050,'group_rows':1001,'entity_months':10010,'conversion_and_read_seconds':round(time.perf_counter()-started,4),'scope':'LOCAL SYNTHETIC CONVERTER TEST ONLY; not Tableau/browser performance'},indent=2))

if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(BuilderTests)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    report={'type':'developer-authored synthetic regression','run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'successful':result.wasSuccessful(),'limitations':['No actual bank raw input was supplied','No Tableau server, RLS, SSO or browser ingestion test','Only the explicitly declared repeated-entity-month balance grain is supported']}
    (ROOT/'test_report.json').write_text(json.dumps(report,indent=2))
    raise SystemExit(0 if result.wasSuccessful() else 1)
