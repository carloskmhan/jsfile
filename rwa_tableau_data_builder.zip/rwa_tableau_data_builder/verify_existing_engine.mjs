/** Optional Node verification against the EXISTING unmodified v5 engine.
 * Usage: node verify_existing_engine.mjs /path/to/v5 /path/to/example_output/tableau_data.csv
 * Generates no customer catalog file; the synthetic catalog exists in memory only.
 */
import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
const dir=path.resolve(process.argv[2]||'');
const csvPath=path.resolve(process.argv[3]||'example_output/tableau_data.csv');
if(!process.argv[2])throw new Error('Supply the original v5 project directory.');
const imp=async p=>import(pathToFileURL(path.join(dir,p)).href);
const {parseCsv,expandCsvRows}=await imp('csv_adapter.js');
const {tableauRowToClient}=await imp('tableau_adapter.js');
const {RwaQaEngine}=await imp('rwa_engine.js');
const {parseRuleText}=await imp('semantic/registry.js');
const input=parseCsv(fs.readFileSync(csvPath,'utf8'));
const catalog={groups:input.map(r=>({client_group_id:r.client_group_id,client_group_name:r.client_group_name,aliases:[]}))};
const fields={id:'client_group_id',name:'client_group_name',location:'group_location',json:'json_data'};
const clients=input.map(r=>tableauRowToClient(r,catalog.groups.find(g=>g.client_group_id===r.client_group_id),fields));
const data=expandCsvRows(clients);
const eng=new RwaQaEngine(data.rows,{...data,semanticCatalog:catalog,commandPatterns:parseRuleText(fs.readFileSync(path.join(dir,'command_patterns.txt'),'utf8')),unit:'USDm',portfolioComplete:true});
const context={selectedClientGroup:'SAMSUNG GROUP',selectedMonth:'2026-07'};
const root=eng.answer('Explain SAMSUNG GROUP in July 2026',context);
assert.equal(root.ok,true);
assert.equal(root.result.originalChange,270);
assert.equal(root.result.rwa_prev,1300);
assert.equal(root.result.rwa_curr,1570);
assert.equal(root.result.main.name,'EAD Increase (STD)');
assert.equal(root.result.main.impact,220);
assert.equal(root.result.reconciled,true);
const attributesLost=data.rows.every(r=>!Object.hasOwn(r,'attributes')&&!Object.hasOwn(r,'cg'));
assert.equal(attributesLost,true); // Records current limitation; this is NOT a desired feature.
eng.reset();
const named=eng.answer('How much came from EAD for SAMSUNG GROUP in July 2026?',context);
assert.equal(named.ok,false); // Fixed EAD lookup is not automatically a roll-up of detail labels.
const hashes=Object.fromEntries(['tableau_adapter.js','csv_adapter.js','rwa_engine.js','semantic/slots.js'].map(p=>[p,crypto.createHash('sha256').update(fs.readFileSync(path.join(dir,p))).digest('hex')]));
const report={scope:'SYNTHETIC JSON/CSV + existing module-level v5 arithmetic test; not live Tableau integration',checks:9,rootReport:root.answer,groupChange:root.result.originalChange,driverTotal:root.result.driverTotal,limitationsObserved:{attributesDroppedByAdapters:attributesLost,namedEadFamilyQuery:named.answer},unmodifiedSourceHashes:hashes};
const outfile=path.join(path.dirname(new URL(import.meta.url).pathname),'existing_engine_report.json');
fs.writeFileSync(outfile,JSON.stringify(report,null,2));
console.log(JSON.stringify(report,null,2));
