# RWA raw CSV -> Tableau JSON-column data builder

**1.0.0-review | Data preparation add-on, NOT a new browser application**

This package preserves the existing four-column v5 transport:

```
client_group_id,client_group_name,group_location,json_data
```

One outer CSV row is one group. `json_data.rows` contains one record per
(group ID, LEID, reporting month), with a dynamic dictionary of reported
additive driver amounts. No fixed list of 20/30 driver columns is required.
All supplied financial examples are synthetic. They are not actual company results.

## Critical assumptions to review BEFORE using real data

1. `client name` and `LEID` are assumed to be two distinct source columns.
   Edit `data_mapping.json` to match the actual headers. Header lookup ignores
   case and surrounding whitespace, but does not guess different field names.
2. The supported balance grain is **repeated entity-month snapshots**: `RWA`,
   `prev_rwa`, EAD, grade and scorecard values repeat on the entity's driver rows.
   Equal snapshots are preserved ONCE. Inconsistent snapshots cause an error.
   If balances instead represent product/facility-level components, this is not
   the correct grain; supply those keys and extend the aggregation first.
3. `RWA Diff by driver` is an already-approved additive RWA attribution amount,
   NOT a repeated total movement and not an independent sensitivity scenario.
   Do not mix overlapping decompositions such as EAD and new-business views.
4. Declare the input amount unit and currency explicitly. All monetary columns
   must already share the SAME unit/currency. Output is USDm. No FX conversion.
5. Input must include the full authorized scope (including unchanged clients),
   not just a filtered list of clients that increased. A reconciled subset does
   not establish complete group balances. Independently reconcile group totals
   to authoritative MI/control totals.
6. The default is one driver label per entity-month. Multiple genuine components
   for the same label require `duplicate_driver_policy=sum_distinct_components`
   AND a mapped source `component_id` column. This is not permission to duplicate
   totals. Component ID uniqueness is checked per entity-month-driver.
7. One canonical group name per group ID. Client names are display labels and may repeat across distinct LEIDs; one LEID still has one canonical client name per build.
   group/LEID are required by the current adapter. Ambiguous names/renames are
   rejected rather than guessed. Production needs an approved as-of identity policy.

## Run

Python 3.10+ standard library only. No pip, pandas, Node or ML is required to convert.

```bash
# Example: amounts are already USD in base units, such as 1,000,000 dollars.
python build_tableau_csv.py --input raw_sample_SYNTHETIC.csv --input-unit base --currency USD --output-dir my_sample_run

# Real data: first edit data_mapping.json to match your actual export.
python build_tableau_csv.py --input raw_data.csv --input-unit base --currency USD --output-dir run_2026_07

# If the raw values are already USD millions, use --input-unit million instead.
```

`base`, `thousand`, `million` mean USD, USD thousands, USD millions respectively.
You can also set `input_amount_unit` and `currency` in the mapping configuration.
Their distributed defaults are null deliberately: the converter does not guess.
Raw CSV must be UTF-8 (BOM permitted); IDs must be exported as text to preserve
leading zeros. Scientific notation and already-rounded IDs cannot be repaired.
The additional date formats option can explicitly enable a source-specific
format such as `%d/%m/%Y`. Ambiguous formats that yield different months fail.

## Output

- `tableau_data.csv`: input for an APPROVED Tableau data source, not a public
  browser data endpoint. JSON quoting/CSV quoting are generated automatically.
- `data_quality.csv`: entity-month original/current RWA, net movement, sum of
  reported drivers and residual, all in USDm. Default residual tolerance is
  0.000001 USDm (USD 1), explicitly configurable; it is not a regulatory standard.
- `driver_inventory.csv`: automatically derived distinct labels and reporting
  coverage. This is a QA output, not a second manually maintained driver master.
- `manifest.json`: counts, units, source/output checksums, per-group JSON sizes
  and limitations. It contains IDs: treat it as confidential with real inputs.

The supplied `example_output/` was generated from the synthetic input, with
6 raw driver rows -> 3 entity-months -> 2 group rows. Samsung's synthetic
prev/current RWA is 1,300/1,570 USDm, not three copies of its first entity balance.

The output directory must NOT already exist. Validation runs before publication;
files are staged in a sibling temporary directory and then renamed. No existing
output is overwritten. Use versioned runs and your normal controlled publishing
process. Do not run concurrent publishers to the same target directory. This is
not authorization or a universal power-failure/transaction guarantee.

## Reconciliation, missing values and driver changes

By default any entity-month residual beyond tolerance stops publication. Explicit
`reconciliation_mode=warn` preserves the residual in QA, never distributes it
among drivers or creates an Other item. Decimal arithmetic is used for validation;
JSON emits finite numbers for the existing JavaScript engine.

Blank/NaN numeric input is not converted to zero. Blank driver names are refused;
provide an approved source representation rather than inventing a label. No
unobserved driver is zero-filled. `Exclude FX` cannot assume missing FX means 0:
the current engine requires an explicit value on every selected record.

New `detail_driver` labels are preserved automatically. Exact label text is the
key in this legacy-compatible output. A rename is therefore a new key. If the
source supplies a stable driver ID, a subsequent browser/data-contract change
should use that ID + display label. The builder does NOT guess that two different
labels describe the same driver or automatically categorize a new label.

Broad family queries such as 'How much came from EAD?' need an approved mapping
from leaf labels to a family. Store that mapping in the authoritative source,
not in a learned model. Do not place a family total and its leaf components in
the same additive `drivers` dictionary: that doubles the attribution.

## Additional attributes

Each generated JSON row retains:

```
attributes.prev_cg
attributes.cg
attributes.ead_prev
attributes.ead_curr
attributes.scorecard_prev
attributes.scorecard_curr
```

Grade/scorecard codes remain strings, including leading zeros/suffixes; EAD is
converted to USDm. Optional unmapped attributes are omitted; mapped blanks become
null. They are not used to infer a rating deterioration or an economic cause.

IMPORTANT: the existing v5 Tableau/CSV adapters discard these extra attributes.
The builder preserves them for the planned patch; it does not claim the current
app answers attribute questions just because the fields exist in JSON.

The user did not supply `group_location`. The compatibility output uses
`NOT_PROVIDED`, not a guessed country. The current group adapter requires that
column to be nonempty. Do not interpret that sentinel as a real location; a
future adapter can make this field optional. Do not change the `fields.location`
configuration to null without also changing the adapter's field validation.

## Tableau setup using ONE data source

Create a data source from `tableau_data.csv` (or publish the equivalent validated
upstream table). Use that same source for:

- `RWA_GROUP_INDEX`: only distinct `client_group_id` and `client_group_name`.
- `RWA_DATA`: the existing four fields, including the complete `json_data` string.

Do not append the full group JSON to every raw driver row and re-sum snapshot
measures. Avoid publishing this CSV as an unauthenticated static web file. The
converted file is an input to the governed Tableau environment.

BOTH worksheets require server-side authorization. If a user can see a group
row's JSON, they can see every client record inside it: worksheet filtering cannot
remove nested JSON fields. Group-packed JSON is only suitable where those nested
clients share the permitted scope. Finer-grained entitlements require filtering
before packing or a client-level transport contract.

For the existing v2 getWorksheets path, include index and detail sheets in the
embedded dashboard. The ordinary 'selected group' filter should not reduce the
index to a single group, but true user/RLS restrictions must remain. Complete
response checks must remain in place; maxRows=0 is not proof of completeness.

## Changes still required in the application (NOT implemented by this package)

- `tableau_config.txt`: add an index source/worksheet/field configuration; keep
  the existing detail fields and source limits. A proposed key is not recognized
  until its loader is implemented.
- `app.js`, `tableau_adapter.js`, `group_catalog.js`, `semantic/routing.js`:
  initialize Tableau before loading the authorized index; remove dependence on
  a separately deployed real-client catalog; invalidate references on changes.
- `semantic/dictionary.js`, `semantic/fuzzy.js`, compiler/schema and local manager:
  source identity candidates at runtime; keep customer names/IDs out of the common
  rule artifact and treat offline sample identities separately.
- Dynamic driver matching: protect full driver label spans BEFORE semantic word
  matching, so 'Increase' inside a driver label is not a query-direction command.
  `semantic/slots.js` currently has a fixed DRIVER_MAP. Replace this binding with
  exact runtime driver IDs/labels plus optional approved family aliases. Keep
  unsupported/ambiguous handling, and do not synthesize empty drivers or causes.
- `tableau_adapter.js`, `csv_adapter.js`, `rwa_engine.js`: explicitly retain and
  validate new attributes, then add approved attribute-report logic/templates.
  Numeric grades require a defined ordering before calling a move an upgrade.
- Unit metadata should be checked end-to-end: current adapters primarily trust
  the app's configured `unit`; adding a JSON metadata field alone does not enforce it.

Thus **data-format compatibility is not the same as complete dynamic NLP and
Tableau-index integration**. This package does not overwrite any v5 runtime,
loading animation, rule CSV, generated command_patterns.txt or local manager.

## Size and export checks

50,000 raw rows are not necessarily 50,000 distinct groups. This converter groups
records before serialization and reports actual JSON bytes per group. Default
payload limit is 5,000,000 UTF-8 bytes; it fails rather than truncating. This is a
local safety limit, NOT proof Tableau will preserve that field size. The existing
adapter's similarly named limit actually checks string length.

Round-trip test the exact largest payload through your Tableau connector,
extract, published worksheet and API. Excel worksheet cells are limited to
32,767 characters; do not open/re-save the generated JSON CSV through Excel.
CSV as a text file has no such worksheet-cell rule, but each tool in the pipeline
has its own limits. Keep the original UTF-8 text and checksums for validation.

A large single-group history may need group-month rows or explicit chunks, which
requires changing the existing `Expected exactly one authorised group row` logic.
Do NOT split it silently while keeping the old adapter. Do not add a month filter
unless month is an actual outer Tableau field; here months are inside JSON.

## Tests

```bash
python test_builder.py

# Optional module-level check against your existing unmodified v5 source; Node required only here.
node verify_existing_engine.mjs /path/to/v5 example_output/tableau_data.csv
```

Tests are developer-authored synthetic cases. The supplied report includes a
50,050-row converter test, not a bank/Tableau performance test. The Node test
asserts both successful general driver reporting and existing limitations:
attributes are dropped, and the EAD-family query has no leaf roll-up yet.
No actual bank raw file, SSO, server RLS, deployment or live Tableau payload
round-trip has been tested.

## Technical references

- Existing user-provided v5 source: tableau_adapter.js, csv_adapter.js,
  semantic/slots.js, semantic/dictionary.js, app.js, rwa_engine.js.
- Tableau v2 API reference (existing app compatibility, deprecated API):
  https://help.tableau.com/current/api/js_api/en-us/JavaScriptAPI/js_api_ref.htm
- Tableau row-level security:
  https://help.tableau.com/current/pro/desktop/en-us/publish_userfilters.htm
- Python CSV writer/reader:
  https://docs.python.org/3/library/csv.html
- Python JSON encoder:
  https://docs.python.org/3/library/json.html
- Excel specifications and limits:
  https://support.microsoft.com/en-us/excel/excel-specifications-and-limits

## Group identity

`client_group_id` is the authoritative unique key. `client_group_name` is a display label and may be duplicated across different group IDs. The builder therefore permits multiple distinct group IDs with the same group name. For a given group ID, its display name and location must remain internally consistent within the build.

## v1.0.3 — previous-group migration handling

The current entity-month identity remains `client_group_id + LEID + Reporting Month`.
Current-side fields (`RWA`, `EAD`, `CG`, `Scorecard`) must be consistent across repeated driver rows.

Previous-side attributes may differ when the same current LEID has records from different prior groups.
If `prev_group` / `prev_group_code` are mapped, the builder preserves distinct prior contexts under:

```json
"attributes": {
  "previous_contexts": [
    {"prev_group":"...","prev_group_code":"...","prev_cg":"...","ead_prev":123,"scorecard_prev":"..."}
  ]
}
```

`prev_ead`, `prev_cg`, and `prev_scorecard` therefore no longer make repeated driver rows fail merely because the previous group differs. A backward-compatible scalar is emitted only when all prior contexts agree; otherwise it is `null`.

`prev_rwa` is still required to be a single consistent entity-month value because the current RWA engine consumes one `rwa_prev`. If `prev_rwa` also varies by prior group/facility, do not sum or pick one blindly; define the actual additive grain/aggregation first.

## v1.0.4 — previous-group split `prev_rwa`

When one current `client_group_id + LEID + Reporting Month` is sourced from more than one previous group, `prev_rwa` may legitimately differ by `prev_group_code`.

The builder now treats the previous side as follows:

- Current identity remains `client_group_id + LEID + Reporting Month`.
- Current-side `RWA`, `EAD`, `CG`, and `Scorecard` must remain consistent across repeated driver rows.
- Previous context identity is `prev_group_code` when present, otherwise `prev_group`, otherwise one implicit previous context.
- Repeated detail-driver rows inside the same previous context must report the same previous-side snapshot.
- `prev_rwa` is counted **once per distinct previous context** and summed across distinct previous groups.
- The JSON row's top-level `rwa_prev` is this deduplicated sum.
- Each previous context is retained under `attributes.previous_contexts`, including its own `rwa_prev`.
- If the same previous-group identity has conflicting `prev_rwa`, the build still stops instead of taking first/MAX or summing duplicate driver rows.

Example:

```text
PG001 prev_rwa = 600m  (repeated on two driver rows)
PG002 prev_rwa = 400m  (one driver row)
=> entity-month rwa_prev = 1,000m, not 1,600m
```
